# 🏗️ TOWER CRUSH

> **Build · Stack · Survive** — Un casual game viral où tu construis des tours et tu testes leur résistance !

![Game](https://img.shields.io/badge/Game-Casual%20Physics-ff2d78?style=for-the-badge)
![Mobile](https://img.shields.io/badge/Mobile-First-00d4ff?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Prototype-05ffa1?style=for-the-badge)

## 🎮 Concept

Construis une structure stable avec différentes pièces (poutres, blocs, triangles, piliers), puis lance le **test de poids**. Si ta tour survit, tu passes au niveau suivant avec un poids encore plus lourd !

**De 5 KG à 300 KG** — Jusqu'où ta tour tiendra ?

## 🕹️ Comment jouer

1. **Choisis** une pièce (poutre, bloc, triangle, pilier)
2. **Positionne** avec la souris ou le doigt
3. **Rotate** pour ajuster l'angle
4. **Drop** pour placer la pièce
5. **Test** ⚡ quand tu es prêt — le poids tombe !

### Contrôles clavier
| Touche | Action |
|--------|--------|
| `← →` | Déplacer la pièce |
| `Espace` | Drop |
| `R` | Rotation |
| `T` | Lancer le test |
| `1-4` | Sélectionner la pièce |

## 🔥 Features

- Physique réaliste (Matter.js)
- 10 niveaux de difficulté croissante
- Système de 🔥 Streak (combo bonus)
- Design néon TikTok-ready
- Glassmorphism UI
- Particules animées
- Mobile-first & responsive
- Zéro dépendance serveur (100% client-side)

## 🚀 Lancer le jeu

Ouvre simplement `index.html` dans un navigateur. C'est tout !

Ou déploie sur GitHub Pages pour un lien partageable.

## 📱 Déployer sur GitHub Pages

1. Va dans **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: **main** / root
4. Ton jeu sera live sur `https://sraitod.github.io/money/`

## 🛠️ Tech Stack

- **Matter.js** — Moteur physique 2D
- **Vanilla JS** — Zéro framework
- **CSS3** — Glassmorphism, animations, néon effects
- **Google Fonts** — Righteous + Outfit

## 📄 License

MIT
