import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import fs from "fs";
import path from "path";
import url from "url";

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const ROOT = path.join(__dirname, "..");
const clientDir = path.join(ROOT, "client");
const dataDir = path.join(ROOT, "shared", "data");

app.use("/data", express.static(dataDir));
app.use("/", express.static(clientDir));

const creatures = JSON.parse(fs.readFileSync(path.join(dataDir, "creatures.json"), "utf-8"));
const rooms = new Map();

function send(ws, obj){ if(ws.readyState === ws.OPEN) ws.send(JSON.stringify(obj)); }
function broadcast(room, obj){
  const r = rooms.get(room);
  if(!r) return;
  r.players.forEach(p=>send(p.ws, obj));
}

function cloneFighterById(id){
  const c = creatures.find(x=>x.id===id);
  return {
    id: c.id,
    name: c.name,
    essences: c.essences,
    hp: c.stats?.hp ?? 90,
    atk: c.stats?.atk ?? 22,
    def: c.stats?.def ?? 18,
    spd: c.stats?.spd ?? 16,
    arts: c.arts,
    rank: c.rank
  };
}

function calcMultiplier(attEss, defEss){
  const strong = {
    "Feu": ["Nature"],
    "Eau": ["Feu","Terre"],
    "Foudre": ["Eau","Vent"],
    "Vent": ["Terre"],
    "Nature": ["Eau"],
    "Ombre": ["Esprit","Lumière"],
    "Lumière": ["Ombre"],
    "Terre": ["Foudre"],
    "Guerre": ["Divin"],
    "Dragon": ["Dragon"],
    "Esprit": ["Guerre"],
    "Divin": ["Dragon","Ombre"]
  };
  if(strong[attEss] && defEss.some(e=>strong[attEss].includes(e))) return 1.25;
  if(attEss==="Ombre" && defEss.includes("Lumière")) return 0.85;
  if(attEss==="Lumière" && defEss.includes("Ombre")) return 0.85;
  return 1.0;
}
function alive(team){ return team.some(x=>x.hp>0); }
function nextAlive(team, idx){ let i=idx; while(i<team.length && team[i].hp<=0) i++; return i; }

function applyAttack(att, def, art){
  const mult = calcMultiplier(att.essences[0], def.essences);
  const raw = Math.max(1, (art.power + att.atk) - Math.floor(def.def/2));
  const dmg = Math.floor(raw * mult);
  def.hp = Math.max(0, def.hp - dmg);
  return {dmg, mult};
}

function pushState(room){
  const r = rooms.get(room);
  if(!r?.state) return;
  const s = r.state;
  r.players.forEach(p=>{
    const me = s.teams[p.id];
    const enemyId = s.playerIds.find(x=>x!==p.id);
    const enemy = s.teams[enemyId];
    send(p.ws, {
      type:"state",
      state:{
        room,
        energy:s.energy,
        turn:s.turn,
        playerId:p.id,
        me:{active: me.fighters[me.activeIdx]},
        enemy:{active: enemy.fighters[enemy.activeIdx]}
      }
    });
  });
}

function endBattle(room, result){
  broadcast(room, {type:"battleEnd", result});
  const r = rooms.get(room);
  if(r) r.state = null;
}

function handleAction(room, playerId, artName){
  const r = rooms.get(room);
  if(!r?.state) return;
  const s = r.state;
  if(s.turn !== playerId) return;

  const enemyId = s.playerIds.find(x=>x!==playerId);
  const me = s.teams[playerId];
  const enemy = s.teams[enemyId];

  const att = me.fighters[me.activeIdx];
  const def = enemy.fighters[enemy.activeIdx];
  const art = att.arts.find(a=>a.name===artName);
  if(!art) return;

  if(art.cost > s.energy){
    broadcast(room, {type:"log", message:"Énergie insuffisante."});
    return;
  }
  s.energy -= art.cost;

  if(art.kind === "buff"){
    if((art.effect||"").includes("+ATK")) att.atk += 4;
    if((art.effect||"").includes("+DEF")) att.def += 4;
    if((art.effect||"").includes("+SPD")) att.spd += 3;
    if((art.effect||"").includes("Bouclier")) att.hp += 12;
    if((art.effect||"").includes("Soin")) att.hp = Math.min(att.hp+18, 140);
    broadcast(room, {type:"log", message:`${att.name} utilise ${art.name}`});
  } else {
    const res = applyAttack(att, def, art);
    broadcast(room, {type:"log", message:`${att.name} utilise ${art.name}: -${res.dmg} HP (x${res.mult})`});
  }

  if(def.hp<=0){
    enemy.activeIdx = nextAlive(enemy.fighters, enemy.activeIdx+1);
    if(!alive(enemy.fighters)){
      endBattle(room, "Victoire !");
      return;
    }
    broadcast(room, {type:"log", message:`L'adversaire envoie ${enemy.fighters[enemy.activeIdx].name}.`});
  }

  s.energy += 1;
  s.turn = enemyId;
  pushState(room);
}

function startBattle(room){
  const r = rooms.get(room);
  if(!r || r.players.length !== 2) return;
  const [p1,p2] = r.players;
  const t1 = p1.teamIds.slice(0,3).map(cloneFighterById);
  const t2 = p2.teamIds.slice(0,3).map(cloneFighterById);
  r.state = {
    room,
    energy:3,
    playerIds:[p1.id,p2.id],
    turn:p1.id,
    teams:{
      [p1.id]:{fighters:t1, activeIdx: nextAlive(t1,0)},
      [p2.id]:{fighters:t2, activeIdx: nextAlive(t2,0)}
    }
  };
  broadcast(room, {type:"status", message:"Duel en ligne démarré."});
  pushState(room);
}

let nextClientId = 1;
wss.on("connection", (ws)=>{
  const clientId = "P"+(nextClientId++);
  send(ws, {type:"status", message:`Connecté (${clientId}).`});

  ws.on("message", (data)=>{
    let msg; try{ msg = JSON.parse(data.toString()); } catch { return; }

    if(msg.type === "join"){
      const room = String(msg.room||"");
      const team = Array.isArray(msg.team) ? msg.team.map(Number) : [];
      if(!room || team.length===0){ send(ws,{type:"status",message:"Salon/équipe invalide."}); return; }

      if(!rooms.has(room)) rooms.set(room, {players:[], state:null});
      const r = rooms.get(room);
      if(r.players.length>=2){ send(ws,{type:"status",message:"Salon plein (2 joueurs)."}); return; }

      r.players.push({id:clientId, ws, teamIds:team});
      ws._room = room; ws._clientId = clientId;
      broadcast(room, {type:"status", message:`${clientId} a rejoint ${room} (${r.players.length}/2).`});

      if(r.players.length===2) startBattle(room);
      else send(ws,{type:"status",message:"En attente d'un adversaire. Partage le code."});
    }

    if(msg.type === "action"){
      if(!ws._room || !ws._clientId) return;
      handleAction(ws._room, ws._clientId, msg.art);
    }
  });

  ws.on("close", ()=>{
    const room = ws._room;
    if(!room) return;
    const r = rooms.get(room);
    if(!r) return;
    r.players = r.players.filter(p=>p.ws!==ws);
    broadcast(room, {type:"status", message:"Un joueur a quitté le salon."});
    if(r.state) endBattle(room, "Fin: adversaire déconnecté.");
    if(r.players.length===0) rooms.delete(room);
  });
});

app.use("/data", express.static(dataDir));
app.use("/", express.static(clientDir));

server.listen(3000, ()=> console.log("MythoMon MVP: http://localhost:3000"));
