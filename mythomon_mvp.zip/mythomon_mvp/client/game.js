(async function () {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const zoneNameEl = document.getElementById('zoneName');
  const coordEl = document.getElementById('coord');
  const teamEl = document.getElementById('team');
  const logEl = document.getElementById('log');

  const overlay = document.getElementById('overlay');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');
  const modalActions = document.getElementById('modalActions');

  const btnDuelAI = document.getElementById('btnDuelAI');
  const btnCodex = document.getElementById('btnCodex');
  const btnOnline = document.getElementById('btnOnline');
  const roomInput = document.getElementById('room');

  const joystick = document.getElementById('joystick');
  const stick = joystick.querySelector('.stick');

  function log(msg){
    const t = new Date().toLocaleTimeString();
    logEl.textContent = `[${t}] ${msg}\n` + logEl.textContent;
  }

  function showModal(title, bodyHtml, actions){
    modalTitle.textContent = title;
    modalBody.innerHTML = bodyHtml;
    modalActions.innerHTML = '';
    actions.forEach(a=>{
      const b = document.createElement('button');
      b.textContent = a.label;
      b.onclick = () => { a.onClick(); };
      modalActions.appendChild(b);
    });
    overlay.classList.remove('hidden');
  }
  function closeModal(){ overlay.classList.add('hidden'); }

  const [map, creatures] = await Promise.all([
    fetch('/data/map_village.json').then(r=>r.json()),
    fetch('/data/creatures.json').then(r=>r.json()),
  ]);
  zoneNameEl.textContent = map.name;

  const pool = creatures.filter(c=>c.rank!=="Primordial" && c.stats);
  function pickOne(){ return pool[Math.floor(Math.random()*pool.length)]; }
  const team = [pickOne(), pickOne(), pickOne()].map(c=>({ ...c, curHp: c.stats.hp }));
  teamEl.textContent = team.map(t=>t.name).join(', ');

  const tileSize = map.tileSize;
  const W = map.width, H = map.height;
  const tiles = map.tiles;

  const colors = {
    grass: '#234a2f',
    wall: '#3a3343',
    water: '#233454',
    path: '#5a4a3a',
    house: '#4b3d2e',
    chest: '#6a5a2a',
    npc: '#2a6a6a',
    gate: '#6a2a52'
  };
  function tileType(ch){ return map.legend[ch] || 'grass'; }

  const player = { x: 4, y: 6, speed: 2.2 };
  const cam = { x:0, y:0 };

  const keys = {};
  window.addEventListener('keydown', e=> keys[e.key.toLowerCase()] = true);
  window.addEventListener('keyup', e=> keys[e.key.toLowerCase()] = false);

  let joyActive = false;
  let joyCenter = {x:0,y:0};
  let joyVec = {x:0,y:0};

  function setStick(dx,dy){
    const max = 40;
    const len = Math.hypot(dx,dy) || 1;
    const cl = Math.min(max, len);
    const nx = dx/len * cl;
    const ny = dy/len * cl;
    stick.style.left = (45 + nx) + 'px';
    stick.style.top  = (45 + ny) + 'px';
    joyVec.x = nx/max;
    joyVec.y = ny/max;
  }
  function resetStick(){
    stick.style.left = '45px';
    stick.style.top = '45px';
    joyVec.x=0; joyVec.y=0;
  }

  joystick.addEventListener('pointerdown', (e)=>{
    joyActive = true;
    const rect = joystick.getBoundingClientRect();
    joyCenter = { x: rect.left + rect.width/2, y: rect.top + rect.height/2 };
    setStick(e.clientX-joyCenter.x, e.clientY-joyCenter.y);
    joystick.setPointerCapture(e.pointerId);
  });
  joystick.addEventListener('pointermove', (e)=>{ if(joyActive) setStick(e.clientX-joyCenter.x, e.clientY-joyCenter.y); });
  joystick.addEventListener('pointerup', ()=>{ joyActive=false; resetStick(); });

  function isBlocked(tx,ty){
    const xi = Math.floor(tx), yi = Math.floor(ty);
    const row = tiles[yi] || "";
    const ch = row[xi] || "#";
    const t = tileType(ch);
    return (t === 'wall' || t === 'house');
  }

  function cloneFighter(creature){
    return {
      id: creature.id,
      name: creature.name,
      essences: creature.essences,
      hp: creature.stats.hp,
      atk: creature.stats.atk,
      def: creature.stats.def,
      spd: creature.stats.spd,
      arts: creature.arts,
      gift: creature.gift,
      rank: creature.rank
    };
  }

  function calcMultiplier(attEss, defEss){
    const strong = {
      "Feu": ["Nature"],
      "Eau": ["Feu","Terre"],
      "Foudre": ["Eau","Vent"],
      "Vent": ["Terre"],
      "Nature": ["Eau"],
      "Ombre": ["Esprit","Lumière"],
      "Lumière": ["Ombre"],
      "Terre": ["Foudre"],
      "Guerre": ["Divin"],
      "Dragon": ["Dragon"],
      "Esprit": ["Guerre"],
      "Divin": ["Dragon","Ombre"]
    };
    if(strong[attEss] && defEss.some(e=>strong[attEss].includes(e))) return 1.25;
    if(attEss==="Ombre" && defEss.includes("Lumière")) return 0.85;
    if(attEss==="Lumière" && defEss.includes("Ombre")) return 0.85;
    return 1.0;
  }

  function chooseArt(f){
    const attacks = f.arts.filter(a=>a.kind==="attaque");
    return attacks[Math.floor(Math.random()*attacks.length)];
  }

  function battleSim(myTeam, enemyTeam){
    let my = myTeam.map(cloneFighter);
    let en = enemyTeam.map(cloneFighter);
    let myIdx = 0, enIdx = 0;
    let energy = 3;

    function alive(team){ return team.some(x=>x.hp>0); }
    function active(team, idx){ while(idx < team.length && team[idx].hp<=0) idx++; return idx; }
    myIdx = active(my, myIdx);
    enIdx = active(en, enIdx);

    function render(){
      const a = my[myIdx], b = en[enIdx];
      return `
        <div style="display:grid;gap:10px;grid-template-columns:1fr 1fr">
          <div>
            <h3>Ton actif</h3>
            <div><b>${a.name}</b> (${a.essences.join('/')})</div>
            <div>HP: ${a.hp}</div>
          </div>
          <div>
            <h3>Adversaire</h3>
            <div><b>${b.name}</b> (${b.essences.join('/')})</div>
            <div>HP: ${b.hp}</div>
          </div>
        </div>
        <hr style="opacity:.15"/>
        <div><b>Énergie</b>: ${energy}</div>
      `;
    }

    function end(result){
      closeModal();
      showModal("Fin de duel", `<div>${result}</div>`, [{label:"OK", onClick: closeModal}]);
    }

    function applyAttack(att, def, art){
      const attEss = att.essences[0];
      const mult = calcMultiplier(attEss, def.essences);
      const raw = Math.max(1, (art.power + att.atk) - Math.floor(def.def/2));
      const dmg = Math.floor(raw * mult);
      def.hp = Math.max(0, def.hp - dmg);
      return {dmg, mult};
    }

    function myTurn(){
      const a = my[myIdx];
      const b = en[enIdx];

      const actions = a.arts.map(art=>({
        label: `${art.name} (${art.cost})`,
        onClick: () => {
          if(art.cost > energy){ log("Énergie insuffisante."); return; }
          energy -= art.cost;

          if(art.kind==="buff"){
            if((art.effect||"").includes("+ATK")) a.atk += 4;
            if((art.effect||"").includes("+DEF")) a.def += 4;
            if((art.effect||"").includes("+SPD")) a.spd += 3;
            if((art.effect||"").includes("Bouclier")) a.hp += 12;
            if((art.effect||"").includes("Soin")) a.hp = Math.min(a.hp+18, 140);
            log(`Tu utilises ${art.name}`);
          } else {
            const res = applyAttack(a,b,art);
            log(`Tu utilises ${art.name}: -${res.dmg} HP (x${res.mult})`);
          }

          if(b.hp<=0){
            enIdx = active(en, enIdx+1);
            if(!alive(en)){ end("Victoire !"); return; }
            log(`L'adversaire envoie ${en[enIdx].name}.`);
          }

          enemyTurn();
        }
      }));

      showModal("Duel IA", render(), actions.concat([{label:"Fuir", onClick: ()=>end("Tu as fui.")}]));
    }

    function enemyTurn(){
      const a = my[myIdx];
      const b = en[enIdx];
      const art = chooseArt(b);
      const res = applyAttack(b,a,art);
      log(`Adversaire utilise ${art.name}: -${res.dmg} HP (x${res.mult})`);
      if(a.hp<=0){
        myIdx = active(my, myIdx+1);
        if(!alive(my)){ end("Défaite…"); return; }
        log(`Tu envoies ${my[myIdx].name}.`);
      }
      energy += 1;
      closeModal();
      myTurn();
    }

    log("Duel IA lancé.");
    myTurn();
  }

  function randomEnemyTeam(){
    const e = [];
    for(let i=0;i<3;i++) e.push(pickOne());
    return e;
  }

  let ws = null;
  function startOnline(room){
    if(ws) ws.close();
    ws = new WebSocket(`ws://${location.hostname}:3000`);
    ws.onopen = ()=>{
      log("Connecté au serveur en ligne.");
      ws.send(JSON.stringify({type:"join", room, team: team.map(t=>t.id)}));
    };
    ws.onmessage = (ev)=>{
      const msg = JSON.parse(ev.data);
      if(msg.type==="status") log(msg.message);
      if(msg.type==="state"){
        const s = msg.state;
        const myA = s.me.active;
        const enA = s.enemy.active;
        const body = `
          <div style="display:grid;gap:10px;grid-template-columns:1fr 1fr">
            <div>
              <h3>Ton actif</h3>
              <div><b>${myA.name}</b> (${myA.essences.join('/')})</div>
              <div>HP: ${myA.hp}</div>
            </div>
            <div>
              <h3>Adversaire</h3>
              <div><b>${enA.name}</b> (${enA.essences.join('/')})</div>
              <div>HP: ${enA.hp}</div>
            </div>
          </div>
          <hr style="opacity:.15"/>
          <div><b>Énergie</b>: ${s.energy}</div>
          <div><b>Tour</b>: ${s.turn === s.playerId ? "Toi" : "Adversaire"}</div>
        `;
        const actions = [];
        if(s.turn === s.playerId){
          myA.arts.forEach(a=>{
            actions.push({label:`${a.name} (${a.cost})`, onClick: ()=> ws.send(JSON.stringify({type:"action", room, art: a.name}))});
          });
        } else {
          actions.push({label:"Attendre…", onClick: ()=>{}});
        }
        actions.push({label:"Quitter", onClick: ()=>{ ws.close(); closeModal(); }});
        showModal("Duel en ligne", body, actions);
      }
      if(msg.type==="log") log(msg.message);
      if(msg.type==="battleEnd"){
        closeModal();
        showModal("Fin duel en ligne", `<div>${msg.result}</div>`, [{label:"OK", onClick: closeModal}]);
      }
    };
    ws.onclose = ()=> log("Déconnecté du serveur en ligne.");
  }

  btnDuelAI.onclick = ()=> battleSim(team, randomEnemyTeam());
  btnCodex.onclick = ()=>{
    const list = creatures.map(c=>`<li><b>${c.name}</b> — ${c.rank} — ${c.essences.join('/')}<br/><span style="opacity:.8">${c.appearance}</span></li>`).join('');
    showModal("Codex (131)", `<ol style="padding-left:18px">${list}</ol>`, [{label:"Fermer", onClick: closeModal}]);
  };
  btnOnline.onclick = ()=>{
    const room = (roomInput.value || "").trim() || Math.random().toString(36).slice(2,8);
    roomInput.value = room;
    startOnline(room);
  };
  overlay.addEventListener('click', (e)=>{ if(e.target === overlay) closeModal(); });

  let last = performance.now();
  function step(now){
    const dt = Math.min(0.033, (now-last)/1000);
    last = now;

    let ix = 0, iy = 0;
    if(keys['arrowleft']||keys['a']) ix -= 1;
    if(keys['arrowright']||keys['d']) ix += 1;
    if(keys['arrowup']||keys['w']) iy -= 1;
    if(keys['arrowdown']||keys['s']) iy += 1;
    ix += joyVec.x; iy += joyVec.y;

    const len = Math.hypot(ix,iy);
    if(len>1){ ix/=len; iy/=len; }

    const nx = player.x + ix * player.speed * dt;
    const ny = player.y + iy * player.speed * dt;

    if(!isBlocked(nx, player.y)) player.x = nx;
    if(!isBlocked(player.x, ny)) player.y = ny;

    cam.x = player.x*tileSize - canvas.width/2 + tileSize/2;
    cam.y = player.y*tileSize - canvas.height/2 + tileSize/2;

    render();
    requestAnimationFrame(step);
  }

  function render(){
    ctx.clearRect(0,0,canvas.width,canvas.height);

    for(let y=0;y<H;y++){
      const row = tiles[y];
      for(let x=0;x<W;x++){
        const ch = row[x];
        const t = tileType(ch);
        ctx.fillStyle = colors[t] || '#222';
        const px = x*tileSize - cam.x;
        const py = y*tileSize - cam.y;
        if(px+tileSize<0||py+tileSize<0||px>canvas.width||py>canvas.height) continue;
        ctx.fillRect(px,py,tileSize,tileSize);
      }
    }

    const px = player.x*tileSize - cam.x;
    const py = player.y*tileSize - cam.y;
    ctx.fillStyle = '#e8e8f0';
    ctx.fillRect(px+4,py+4, tileSize-8, tileSize-8);
    coordEl.textContent = `${player.x.toFixed(2)}, ${player.y.toFixed(2)}`;
  }

  log("MVP prêt: bouge sur la map, lance Duel IA ou Duel en ligne.");
  requestAnimationFrame(step);
})();