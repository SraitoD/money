# MythoMon MVP (mobile-first)

Prototype jouable :
- Exploration top-down (joystick mobile + WASD/flèches)
- Codex (131 Mythocréatures générées)
- Duel IA (tour par tour)
- Duel en ligne (2 joueurs) via WebSocket (code de salon)

## Lancer (Node.js 18+)
```bash
cd mythomon_mvp/server
npm install
npm start
```

Ouvre http://localhost:3000

## Duel en ligne
- Appareil A: clique Duel en ligne -> code de salon
- Appareil B: mets le même code -> Duel en ligne
