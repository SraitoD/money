import express from "express";
import path from "path";
import url from "url";

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const app = express();

app.use("/", express.static(path.join(__dirname, "..", "client")));
app.use("/data", express.static(path.join(__dirname, "..", "data")));

app.listen(3000, ()=> console.log("MythoMon v2: http://localhost:3000"));
