# MythoMon — GBA Casual v2

Prototype jouable (sans assets externes) :
- Map style GBA (tiles 16x16)
- Entrer/sortir de maison (intérieur séparé)
- Entrer/sortir de grotte (sous-sol)
- Changement de zone (Zone 1 <-> Zone 2)
- PNJ avec dialogue (E / Entrée / bouton A mobile)
- Coffre
- Rencontres aléatoires
- Combat simple avec attaques limitées (PP)

## Lancer
```bash
cd server
npm install
npm start
```
Ouvre http://localhost:3000
