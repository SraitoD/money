
(async function(){
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");

  const mapNameEl = document.getElementById("mapName");
  const coordEl = document.getElementById("coord");
  const zoneEl = document.getElementById("zone");
  const lvlRangeEl = document.getElementById("lvlRange");
  const teamEl = document.getElementById("team");
  const logEl = document.getElementById("log");

  const overlay = document.getElementById("overlay");
  const modalTitle = document.getElementById("modalTitle");
  const modalBody = document.getElementById("modalBody");
  const modalActions = document.getElementById("modalActions");

  const btnCodex = document.getElementById("btnCodex");
  const btnSave = document.getElementById("btnSave");
  const btnLoad = document.getElementById("btnLoad");

  const joystick = document.getElementById("joystick");
  const stick = joystick.querySelector(".stick");
  const aBtn = document.getElementById("aBtn");

  function log(m){
    const t = new Date().toLocaleTimeString();
    logEl.textContent = `[${t}] ${m}\n` + logEl.textContent;
  }

  function showModal(title, bodyHtml, actions){
    modalTitle.textContent = title;
    modalBody.innerHTML = bodyHtml;
    modalActions.innerHTML = "";
    actions.forEach(a=>{
      const b = document.createElement("button");
      b.textContent = a.label;
      b.onclick = a.onClick;
      modalActions.appendChild(b);
    });
    overlay.classList.remove("hidden");
  }
  function closeModal(){ overlay.classList.add("hidden"); }
  overlay.addEventListener("click",(e)=>{ if(e.target===overlay) closeModal(); });

  const [zones, creatures] = await Promise.all([
    fetch("/data/zones/zones.json").then(r=>r.json()),
    fetch("/data/creatures/creatures.json").then(r=>r.json()),
  ]);

  // --- Save / Load ---
  const SAVE_KEY = "mythomon_save_v2";
  function saveGame(){
    const data = { mapId: state.mapId, player: state.player, zoneId: state.zoneId, team: state.team, pp: state.pp, inventory: state.inventory };
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    log("Sauvegarde OK.");
  }
  function loadGame(){
    const raw = localStorage.getItem(SAVE_KEY);
    if(!raw){ log("Aucune sauvegarde."); return; }
    const data = JSON.parse(raw);
    state.zoneId = data.zoneId ?? 1;
    state.team = data.team ?? state.team;
    state.pp = data.pp ?? state.pp;
    state.inventory = data.inventory ?? state.inventory;
    loadMap(data.mapId ?? "zone1_overworld", data.player?.x, data.player?.y);
    log("Sauvegarde chargée.");
  }

  btnSave.onclick = saveGame;
  btnLoad.onclick = loadGame;

  // --- Input ---
  const keys = {};
  addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
  addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

  let joyActive=false, joyCenter={x:0,y:0}, joyVec={x:0,y:0};
  function setStick(dx,dy){
    const max=40;
    const len=Math.hypot(dx,dy)||1;
    const cl=Math.min(max,len);
    const nx=dx/len*cl, ny=dy/len*cl;
    stick.style.left=(45+nx)+"px";
    stick.style.top =(45+ny)+"px";
    joyVec.x=nx/max; joyVec.y=ny/max;
  }
  function resetStick(){ stick.style.left="45px"; stick.style.top="45px"; joyVec.x=0; joyVec.y=0; }
  joystick.addEventListener("pointerdown",(e)=>{
    joyActive=true;
    const r=joystick.getBoundingClientRect();
    joyCenter={x:r.left+r.width/2,y:r.top+r.height/2};
    setStick(e.clientX-joyCenter.x,e.clientY-joyCenter.y);
    joystick.setPointerCapture(e.pointerId);
  });
  joystick.addEventListener("pointermove",(e)=>{ if(joyActive) setStick(e.clientX-joyCenter.x,e.clientY-joyCenter.y); });
  joystick.addEventListener("pointerup",()=>{ joyActive=false; resetStick(); });

  // --- State ---
  const pool = creatures.filter(c=>c.rank!=="Primordial");
  const pick = ()=> pool[Math.floor(Math.random()*pool.length)];
  const mkFighter = (c, lvl)=>{
    const mult = 1 + (lvl-1)*0.06;
    return {
      id: c.id, name: c.name, essences: c.essences,
      lvl,
      hpMax: Math.floor(c.base.hp*mult),
      hp: Math.floor(c.base.hp*mult),
      atk: Math.floor(c.base.atk*mult),
      def: Math.floor(c.base.def*mult),
      spd: Math.floor(c.base.spd*mult),
    };
  };

  const state = {
    zoneId: 1,
    mapId: "zone1_overworld",
    map: null,
    tileSize: 16,
    cam: {x:0,y:0},
    player: {x:6,y:12, dir:"down", anim:0, speed:3.0},
    team: [mkFighter(pick(), 6), mkFighter(pick(), 5), mkFighter(pick(), 4)],
    activeIdx: 0,
    inventory: { potion: 2 },
    // PP (attaque possible)
    pp: {
      // moveKey: {name, pp, ppMax, power}
      m1: {name:"Frappe", pp: 25, ppMax:25, power: 18},
      m2: {name:"Art", pp: 12, ppMax:12, power: 30},
      m3: {name:"Focus", pp: 10, ppMax:10, power: 0}, // buff
      m4: {name:"Capture", pp: 8, ppMax:8, power: 0},
    },
    inBattle: false,
    battle: null,
  };

  function updateHUD(){
    const z = zones.zones.find(x=>x.id===state.zoneId) || zones.zones[0];
    zoneEl.textContent = String(z.id);
    lvlRangeEl.textContent = `${z.level_range[0]}–${z.level_range[1]}`;
    teamEl.textContent = state.team.map((t,i)=> (i===state.activeIdx?`[${t.name} Lv${t.lvl}]`:`${t.name} Lv${t.lvl}`)).join(", ");
    mapNameEl.textContent = state.map?.name ?? "—";
    coordEl.textContent = `${state.player.x.toFixed(2)}, ${state.player.y.toFixed(2)}`;
  }

  // --- Maps ---
  async function fetchMap(mapId){
    return fetch(`/data/maps/${mapId}.json`).then(r=>r.json());
  }

  function tileAt(x,y){
    const xi=Math.floor(x), yi=Math.floor(y);
    const row=state.map.tiles[yi] || "";
    return row[xi] || "#";
  }
  function tileSolid(ch){
    return ch==="#" || ch==="T" || ch==="H" || ch==="X" || ch==="^";
  }
  function tileEncounter(ch){
    // tall grass or cave floor
    return ch==="," || ch==="=";
  }

  function loadMap(mapId, x=null, y=null){
    return fetchMap(mapId).then(m=>{
      state.mapId = mapId;
      state.map = m;
      state.tileSize = m.tileSize || 16;
      state.player.x = (x!=null)?x:(m.spawn?.x ?? 2);
      state.player.y = (y!=null)?y:(m.spawn?.y ?? 2);
      updateHUD();
      log(`Map chargée: ${m.name}`);
    });
  }

  // --- NPC interaction ---
  function nearbyNpc(){
    for(const n of (state.map.npcs||[])){
      const dx = Math.abs(n.x - Math.floor(state.player.x));
      const dy = Math.abs(n.y - Math.floor(state.player.y));
      if(dx+dy===1) return n;
    }
    return null;
  }
  function talkToNpc(npc){
    let idx=0;
    function render(){
      const text = npc.dialog[idx] || "";
      const body = `<div style="padding:6px 0"><b>PNJ</b> : ${text}</div>
                    <div style="opacity:.7;font-size:12px">Appuie sur Suivant</div>`;
      showModal("Dialogue", body, [
        {label: idx < npc.dialog.length-1 ? "Suivant" : "Fin", onClick: ()=>{
          if(idx < npc.dialog.length-1){ idx++; render(); }
          else closeModal();
        }}
      ]);
    }
    render();
  }

  // --- Links (doors, zone change) ---
  function checkLink(){
    const px=Math.floor(state.player.x), py=Math.floor(state.player.y);
    for(const l of (state.map.links||[])){
      if(l.from.x===px && l.from.y===py){
        // zone update if needed
        if(l.type==="zone"){
          // crude: if going to zone2_overworld set zoneId=2 else keep
          if(l.to.map==="zone2_overworld") state.zoneId = 2;
          if(l.to.map==="zone1_overworld") state.zoneId = 1;
        }
        return loadMap(l.to.map, l.to.x, l.to.y);
      }
    }
    return null;
  }

  // --- Chest ---
  const opened = new Set();
  function checkChest(){
    const px=Math.floor(state.player.x), py=Math.floor(state.player.y);
    for(const c of (state.map.chests||[])){
      if(c.x===px && c.y===py && !opened.has(c.id)){
        opened.add(c.id);
        if(c.loot?.id==="potion") state.inventory.potion = (state.inventory.potion||0) + (c.loot.qty||1);
        log(`Coffre: +${c.loot?.name ?? "objet"} x${c.loot?.qty ?? 1}`);
        showModal("Coffre", `<div>Tu trouves: <b>${c.loot?.name}</b> x${c.loot?.qty ?? 1}</div>`, [{label:"OK", onClick: closeModal}]);
        return true;
      }
    }
    return false;
  }

  // --- Battle ---
  function randomEnemy(){
    const z = zones.zones.find(x=>x.id===state.zoneId) || zones.zones[0];
    const lvl = Math.floor(z.level_range[0] + Math.random()*(z.level_range[1]-z.level_range[0]+1));
    return mkFighter(pick(), lvl);
  }

  function battleUI(){
    const me = state.team[state.activeIdx];
    const en = state.battle.enemy;
    const pp = state.pp;
    const hpBar = (cur,max)=> {
      const pct = Math.max(0, Math.min(1, cur/max));
      const w = Math.floor(pct*140);
      return `<div class="hpWrap"><div class="hpFill" style="width:${w}px"></div></div><div style="font-size:12px;opacity:.85">${cur}/${max}</div>`;
    };

    const btn = (key, label, disabled=false) => {
      const m = pp[key];
      const dis = disabled || m.pp<=0;
      const sub = (m.pp<=0) ? "— épuisé" : `PP ${m.pp}/${m.ppMax}`;
      return `<button class="bbtn" data-m="${key}" ${dis?"disabled":""}>${label}<div class="bsub">${sub}</div></button>`;
    };

    return `
      <style>
        .battle{display:grid;gap:10px;grid-template-columns:1fr 1fr}
        .card{border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:10px;background:rgba(255,255,255,.03)}
        .hpWrap{width:140px;height:10px;border-radius:6px;background:rgba(255,255,255,.10);overflow:hidden;border:1px solid rgba(255,255,255,.10)}
        .hpFill{height:100%;background:rgba(120,220,120,.85)}
        .actions{display:grid;gap:8px;grid-template-columns:1fr 1fr}
        .bbtn{background:#2a2f52;color:#fff;border:1px solid rgba(255,255,255,.12);padding:10px;border-radius:12px;font-weight:900;text-align:left}
        .bbtn:disabled{opacity:.45}
        .bsub{font-size:11px;opacity:.75;margin-top:3px}
      </style>
      <div class="battle">
        <div class="card">
          <div><b>${me.name}</b> <span style="opacity:.8">Lv${me.lvl}</span></div>
          <div style="opacity:.8;font-size:12px">${me.essences.join("/")}</div>
          ${hpBar(me.hp, me.hpMax)}
        </div>
        <div class="card">
          <div><b>${en.name}</b> <span style="opacity:.8">Lv${en.lvl}</span></div>
          <div style="opacity:.8;font-size:12px">${en.essences.join("/")}</div>
          ${hpBar(en.hp, en.hpMax)}
        </div>
      </div>
      <div style="margin-top:10px;opacity:.85"><b>Actions</b> (attaques limitées)</div>
      <div class="actions" style="margin-top:8px">
        ${btn("m1", pp.m1.name)}
        ${btn("m2", pp.m2.name)}
        ${btn("m3", pp.m3.name)}
        ${btn("m4", pp.m4.name)}
      </div>
      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
        <button id="btnPotion">Potion (${state.inventory.potion||0})</button>
        <button id="btnSwitch">Changer</button>
        <button id="btnRun">Fuir</button>
      </div>
      <div style="margin-top:10px;font-size:12px;opacity:.75">Astuce: "Capture" marche mieux si l'ennemi a peu de PV.</div>
    `;
  }

  function startBattle(reason="Rencontre"){
    state.inBattle = true;
    const enemy = randomEnemy();
    state.battle = { enemy, buffed:false };
    log(`${reason}: ${enemy.name} (Lv${enemy.lvl})`);
    renderBattle();
  }

  function endBattle(result){
    state.inBattle = false;
    state.battle = null;
    closeModal();
    showModal("Fin du duel", `<div>${result}</div>`, [{label:"OK", onClick: closeModal}]);
  }

  function damage(att, def, power){
    const raw = Math.max(1, power + att.atk - Math.floor(def.def/2));
    return Math.floor(raw);
  }

  function enemyTurn(){
    const me = state.team[state.activeIdx];
    const en = state.battle.enemy;
    // simple AI: basic hit
    const dmg = damage(en, me, 16);
    me.hp = Math.max(0, me.hp - dmg);
    log(`Ennemi attaque: -${dmg} PV`);
    if(me.hp<=0){
      log(`${me.name} est K.O.`);
      // auto switch if possible
      const idx = state.team.findIndex(t=>t.hp>0);
      if(idx>=0){
        state.activeIdx = idx;
        log(`Tu envoies ${state.team[state.activeIdx].name}.`);
      } else {
        endBattle("Défaite…");
        return;
      }
    }
    renderBattle();
  }

  function renderBattle(){
    showModal("Combat", battleUI(), [
      {label:"Fermer", onClick: ()=>{ /* lock during battle */ }}
    ]);
    // wire buttons
    const root = modalBody;
    root.querySelectorAll("[data-m]").forEach(b=>{
      b.addEventListener("click", ()=>{
        const key = b.getAttribute("data-m");
        playerMove(key);
      });
    });
    const btnPotion = root.querySelector("#btnPotion");
    const btnSwitch = root.querySelector("#btnSwitch");
    const btnRun = root.querySelector("#btnRun");
    btnPotion.onclick = ()=>{
      if((state.inventory.potion||0)<=0){ log("Plus de potion."); return; }
      const me = state.team[state.activeIdx];
      state.inventory.potion -= 1;
      me.hp = Math.min(me.hpMax, me.hp + 35);
      log("Potion: +35 PV");
      enemyTurn();
    };
    btnSwitch.onclick = ()=>{
      const options = state.team.map((t,i)=>({i, t})).filter(o=>o.t.hp>0);
      const body = options.map(o=>`<div style="padding:6px 0"><b>${o.t.name}</b> Lv${o.t.lvl} — HP ${o.t.hp}/${o.t.hpMax} <button data-sw="${o.i}">Choisir</button></div>`).join("");
      showModal("Changer", body, [{label:"Retour", onClick: renderBattle}]);
      modalBody.querySelectorAll("[data-sw]").forEach(bb=>{
        bb.onclick = ()=>{
          state.activeIdx = Number(bb.getAttribute("data-sw"));
          log(`Changement: ${state.team[state.activeIdx].name}`);
          enemyTurn();
        };
      });
    };
    btnRun.onclick = ()=> endBattle("Tu as fui.");
  }

  function playerMove(key){
    const me = state.team[state.activeIdx];
    const en = state.battle.enemy;
    const m = state.pp[key];
    if(m.pp<=0){ log("Attaque épuisée."); return; }
    m.pp -= 1;

    if(key==="m3"){ // buff focus
      state.battle.buffed = true;
      log("Focus: ATK augmente pour ce combat.");
      enemyTurn();
      return;
    }
    if(key==="m4"){ // capture attempt
      const hpPct = en.hp / en.hpMax;
      const chance = Math.max(0.08, 0.55 - hpPct*0.45);
      if(Math.random() < chance){
        log(`Capture réussie: ${en.name} !`);
        // add to team if space else ignore
        if(state.team.length < 3){
          state.team.push(en);
          log("Ajouté à l'équipe.");
        } else {
          log("Équipe pleine (démo).");
        }
        endBattle("Capture réussie !");
      } else {
        log("Capture échouée.");
        enemyTurn();
      }
      return;
    }

    // attack
    const power = (key==="m2") ? m.power : m.power;
    let pwr = power;
    if(state.battle.buffed && (key==="m1" || key==="m2")) pwr = Math.floor(pwr*1.25);
    const dmg = damage(me, en, pwr);
    en.hp = Math.max(0, en.hp - dmg);
    log(`${m.name}: -${dmg} PV`);
    if(en.hp<=0){
      // XP / level up (simple)
      me.lvl = Math.min(99, me.lvl + 1);
      me.hpMax = Math.floor(me.hpMax * 1.05);
      me.atk = Math.floor(me.atk * 1.03);
      me.def = Math.floor(me.def * 1.03);
      me.spd = Math.floor(me.spd * 1.02);
      me.hp = Math.min(me.hpMax, me.hp + 20);
      updateHUD();
      endBattle(`Victoire ! ${me.name} passe Lv${me.lvl}.`);
      return;
    }
    enemyTurn();
  }

  // --- Codex ---
  btnCodex.onclick = ()=>{
    const list = creatures.slice(0,131).map(c=>`<li><b>${c.name}</b> — ${c.essences.join("/")} — ${c.rank}</li>`).join("");
    showModal("Codex (131)", `<ol style="padding-left:18px">${list}</ol>`, [{label:"Fermer", onClick: closeModal}]);
  };

  // A button = interact
  function interact(){
    if(state.inBattle) return;
    const npc = nearbyNpc();
    if(npc) return talkToNpc(npc);
    // chest can be opened by stepping, already handled
    log("Rien à interagir.");
  }
  aBtn.addEventListener("click", interact);
  addEventListener("keydown",(e)=>{
    if(e.key.toLowerCase()==="e" || e.key==="Enter") interact();
  });

  // --- Rendering tiles (procedural but nicer) ---
  function pxRect(x,y,w,h){ ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h)); }
  function drawGrass(x,y,seed){
    ctx.fillStyle="#1f6a3a"; pxRect(x,y,16,16);
    ctx.fillStyle="rgba(255,255,255,0.06)";
    for(let i=0;i<3;i++){
      const dx=(seed*13+i*5)%14, dy=(seed*7+i*9)%14;
      pxRect(x+dx,y+dy,2,2);
    }
  }
  function drawTall(x,y,seed,t){
    ctx.fillStyle="#246f3f"; pxRect(x,y,16,16);
    for(let i=0;i<4;i++){
      const dx=(seed*11+i*4)%16;
      const sway=Math.sin(t*3+seed+i)*1.1;
      ctx.fillStyle="rgba(255,255,255,0.08)";
      pxRect(x+dx,y+3+sway,1,10);
    }
  }
  function drawWater(x,y,t){
    ctx.fillStyle="#264e8a"; pxRect(x,y,16,16);
    ctx.fillStyle="rgba(255,255,255,0.12)";
    const yy=y+4+Math.floor((Math.sin(t*2+(x+y)*0.02)+1)*2);
    pxRect(x+2,yy,12,2);
  }
  function drawWall(x,y){ ctx.fillStyle="#4b445a"; pxRect(x,y,16,16); ctx.fillStyle="rgba(0,0,0,0.18)"; pxRect(x,y,16,3); }
  function drawPath(x,y){ ctx.fillStyle="#8a6a46"; pxRect(x,y,16,16); ctx.fillStyle="rgba(255,255,255,0.06)"; pxRect(x+2,y+2,12,2); }
  function drawTree(x,y,t){ ctx.fillStyle="#6a4b2f"; pxRect(x+7,y+9,2,6); ctx.fillStyle="#1f5f35"; pxRect(x+3,y+3,10,8); ctx.fillStyle="rgba(255,255,255,0.06)"; const bob=Math.sin(t*2+x*0.01)*1; pxRect(x+4,y+4+bob,3,2); }
  function drawHouse(x,y){ ctx.fillStyle="#6a4b2f"; pxRect(x,y,16,16); ctx.fillStyle="#3a2a1d"; pxRect(x+3,y+5,10,8); }
  function drawDoor(x,y){ ctx.fillStyle="#6a4b2f"; pxRect(x,y,16,16); ctx.fillStyle="#1d1a10"; pxRect(x+5,y+5,6,10); ctx.fillStyle="#d9c27a"; pxRect(x+10,y+10,2,2); }
  function drawGate(x,y){ ctx.fillStyle="#7c2a62"; pxRect(x,y,16,16); ctx.fillStyle="rgba(255,255,255,0.10)"; pxRect(x+4,y+4,8,2); pxRect(x+4,y+9,8,2); }
  function drawSand(x,y,seed){ ctx.fillStyle="#b89b4b"; pxRect(x,y,16,16); ctx.fillStyle="rgba(0,0,0,0.06)"; const dx=(seed*9)%12; pxRect(x+dx,y+9,4,2); }
  function drawCave(x,y,seed){ ctx.fillStyle="#3b3a3a"; pxRect(x,y,16,16); ctx.fillStyle="rgba(255,255,255,0.05)"; const dx=(seed*7)%12; pxRect(x+2+dx%6,y+2,2,2); }
  function drawRock(x,y){ ctx.fillStyle="#2d2b2b"; pxRect(x,y,16,16); ctx.fillStyle="rgba(255,255,255,0.06)"; pxRect(x+2,y+2,12,2); }
  function drawNpc(x,y,t){ ctx.fillStyle="#39b2b2"; pxRect(x+5,y+6,6,8); ctx.fillStyle="rgba(0,0,0,0.25)"; pxRect(x+6,y+7,4,2); }

  function drawPlayer(x,y,t,vx,vy){
    ctx.fillStyle="rgba(0,0,0,0.25)"; pxRect(x+5,y+12,6,2);
    const walking=(Math.abs(vx)+Math.abs(vy))>0.01;
    const bob=walking?Math.sin(t*10+state.player.anim)*1.2:0;
    ctx.fillStyle="#f2e9ff"; pxRect(x+6,y+6+bob,4,6);
    ctx.fillStyle="#f7d7c4"; pxRect(x+5,y+2+bob,6,5);
    ctx.fillStyle="#5c4b9a"; pxRect(x+5,y+2+bob,6,2); pxRect(x+6,y+4+bob,4,1);
    ctx.fillStyle="#1a1a1a";
    if(state.player.dir==="down"){ pxRect(x+6,y+5+bob,1,1); pxRect(x+8,y+5+bob,1,1); }
    else if(state.player.dir==="left"){ pxRect(x+6,y+5+bob,1,1); }
    else if(state.player.dir==="right"){ pxRect(x+8,y+5+bob,1,1); }
    ctx.fillStyle="#d45a6a"; pxRect(x+6,y+7+bob,4,1);
    ctx.fillStyle="#3a3343";
    if(walking){ const step=Math.sin(t*10); pxRect(x+6,y+12+bob,2,1); pxRect(x+8,y+12+bob+(step>0?0:1),2,1); }
    else pxRect(x+6,y+12+bob,4,1);
  }

  // --- Main loop ---
  let last=performance.now(), time=0;
  let vx=0, vy=0;

  function step(now){
    const dt=Math.min(0.033,(now-last)/1000);
    last=now; time+=dt;

    if(!state.map){ requestAnimationFrame(step); return; }
    if(state.inBattle){ requestAnimationFrame(step); return; } // freeze movement

    let ix=0, iy=0;
    if(keys["arrowleft"]||keys["a"]) ix -= 1;
    if(keys["arrowright"]||keys["d"]) ix += 1;
    if(keys["arrowup"]||keys["w"]) iy -= 1;
    if(keys["arrowdown"]||keys["s"]) iy += 1;

    // joystick influence
    ix += joyVec.x; iy += joyVec.y;

    const len=Math.hypot(ix,iy);
    if(len>1){ ix/=len; iy/=len; }

    vx=ix*state.player.speed; vy=iy*state.player.speed;

    if(Math.abs(ix)>Math.abs(iy)){
      if(ix<-0.1) state.player.dir="left";
      if(ix>0.1) state.player.dir="right";
    } else {
      if(iy<-0.1) state.player.dir="up";
      if(iy>0.1) state.player.dir="down";
    }
    if(Math.hypot(ix,iy)>0.05) state.player.anim += dt;

    const nx = state.player.x + ix*state.player.speed*dt;
    const ny = state.player.y + iy*state.player.speed*dt;

    // collision per axis
    const tx = tileAt(nx, state.player.y);
    if(!tileSolid(tx)) state.player.x = nx;
    const ty = tileAt(state.player.x, ny);
    if(!tileSolid(ty)) state.player.y = ny;

    // camera
    const tileSize = state.tileSize;
    const targetX = state.player.x*tileSize - canvas.width/2 + tileSize/2;
    const targetY = state.player.y*tileSize - canvas.height/2 + tileSize/2;
    state.cam.x += (targetX - state.cam.x) * 0.12;
    state.cam.y += (targetY - state.cam.y) * 0.12;

    // triggers
    checkChest();
    const linkPromise = checkLink();
    if(linkPromise){
      linkPromise.then(()=>updateHUD());
    }

    // random encounter in tall grass/cave
    const ch = tileAt(state.player.x, state.player.y);
    const encounterRate = (ch==="=") ? 0.012 : 0.008;
    if(tileEncounter(ch) && Math.random() < encounterRate){
      startBattle("Rencontre");
    }

    updateHUD();
    render(time);
    requestAnimationFrame(step);
  }

  function render(t){
    const tileSize = state.tileSize;
    ctx.clearRect(0,0,canvas.width,canvas.height);

    // tiles
    for(let y=0;y<state.map.height;y++){
      const row = state.map.tiles[y];
      for(let x=0;x<state.map.width;x++){
        const ch = row[x];
        const px = x*tileSize - state.cam.x;
        const py = y*tileSize - state.cam.y;
        if(px+tileSize<0||py+tileSize<0||px>canvas.width||py>canvas.height) continue;
        const seed=(x+1)*97+(y+1)*131;

        if(ch===".") drawGrass(px,py,seed);
        else if(ch===",") drawTall(px,py,seed,t);
        else if(ch==="~") drawWater(px,py,t);
        else if(ch==="#") drawWall(px,py);
        else if(ch==="P") drawPath(px,py);
        else if(ch==="T") drawTree(px,py,t);
        else if(ch==="H") drawHouse(px,py);
        else if(ch==="D") drawDoor(px,py);
        else if(ch==="G"||ch==="E") drawGate(px,py);
        else if(ch==="S") drawSand(px,py,seed);
        else if(ch==="=") drawCave(px,py,seed);
        else if(ch==="X") drawRock(px,py);
        else drawGrass(px,py,seed);
      }
    }

    // NPCs
    for(const n of (state.map.npcs||[])){
      const px = n.x*tileSize - state.cam.x;
      const py = n.y*tileSize - state.cam.y;
      drawNpc(px,py,t);
      // bubble when near
      const dx = Math.abs(n.x - Math.floor(state.player.x));
      const dy = Math.abs(n.y - Math.floor(state.player.y));
      if(dx+dy===1){
        ctx.fillStyle="rgba(255,255,255,0.85)";
        ctx.fillRect(Math.round(px+6), Math.round(py-4), 4, 4);
      }
    }

    // player
    const ppx = state.player.x*tileSize - state.cam.x;
    const ppy = state.player.y*tileSize - state.cam.y;
    drawPlayer(ppx, ppy, t, vx, vy);

    // vignette
    const g = ctx.createRadialGradient(canvas.width/2, canvas.height/2, 40, canvas.width/2, canvas.height/2, 260);
    g.addColorStop(0,"rgba(0,0,0,0)");
    g.addColorStop(1,"rgba(0,0,0,0.22)");
    ctx.fillStyle=g;
    ctx.fillRect(0,0,canvas.width,canvas.height);
  }

  // Tap-to-interact on canvas (mobile)
  canvas.addEventListener("click", ()=> interact());

  // Start
  await loadMap(state.mapId);
  updateHUD();
  log("Astuce: E / Entrée ou bouton A pour parler aux PNJ. Hautes herbes = rencontres.");
  requestAnimationFrame(step);

})();
