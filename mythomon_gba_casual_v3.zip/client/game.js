
(async function(){
  const canvas=document.getElementById("game");
  const ctx=canvas.getContext("2d");

  const mapNameEl=document.getElementById("mapName");
  const zoneNameEl=document.getElementById("zoneName");
  const lvlRangeEl=document.getElementById("lvlRange");
  const coordEl=document.getElementById("coord");
  const teamEl=document.getElementById("team");
  const logEl=document.getElementById("log");

  const overlay=document.getElementById("overlay");
  const modalTitle=document.getElementById("modalTitle");
  const modalBody=document.getElementById("modalBody");
  const modalActions=document.getElementById("modalActions");

  const btnParty=document.getElementById("btnParty");
  const btnCodex=document.getElementById("btnCodex");
  const btnSave=document.getElementById("btnSave");
  const btnLoad=document.getElementById("btnLoad");

  const joystick=document.getElementById("joystick");
  const stick=joystick.querySelector(".stick");
  const aBtn=document.getElementById("aBtn");

  function log(m){
    const t=new Date().toLocaleTimeString();
    logEl.textContent=`[${t}] ${m}\n`+logEl.textContent;
  }
  function showModal(title, bodyHtml, actions){
    modalTitle.textContent=title;
    modalBody.innerHTML=bodyHtml;
    modalActions.innerHTML="";
    actions.forEach(a=>{
      const b=document.createElement("button");
      b.textContent=a.label;
      b.onclick=a.onClick;
      modalActions.appendChild(b);
    });
    overlay.classList.remove("hidden");
  }
  function closeModal(){ overlay.classList.add("hidden"); }
  overlay.addEventListener("click",(e)=>{ if(e.target===overlay) closeModal(); });

  const [zones, creatures] = await Promise.all([
    fetch("/data/zones/zones.json").then(r=>r.json()),
    fetch("/data/creatures/creatures.json").then(r=>r.json()),
  ]);

  // Input
  const keys={};
  addEventListener("keydown", e => keys[e.key.toLowerCase()]=true);
  addEventListener("keyup", e => keys[e.key.toLowerCase()]=false);

  let joyActive=false, joyCenter={x:0,y:0}, joyVec={x:0,y:0};
  function setStick(dx,dy){
    const max=42;
    const len=Math.hypot(dx,dy)||1;
    const cl=Math.min(max,len);
    const nx=dx/len*cl, ny=dy/len*cl;
    stick.style.left=(47+nx)+"px";
    stick.style.top=(47+ny)+"px";
    joyVec.x=nx/max; joyVec.y=ny/max;
  }
  function resetStick(){ stick.style.left="47px"; stick.style.top="47px"; joyVec.x=0; joyVec.y=0; }
  joystick.addEventListener("pointerdown",(e)=>{
    joyActive=true;
    const r=joystick.getBoundingClientRect();
    joyCenter={x:r.left+r.width/2,y:r.top+r.height/2};
    setStick(e.clientX-joyCenter.x,e.clientY-joyCenter.y);
    joystick.setPointerCapture(e.pointerId);
  });
  joystick.addEventListener("pointermove",(e)=>{ if(joyActive) setStick(e.clientX-joyCenter.x,e.clientY-joyCenter.y); });
  joystick.addEventListener("pointerup",()=>{ joyActive=false; resetStick(); });

  // RNG helpers
  function hash(n){ n=(n^61)^(n>>>16); n=n+(n<<3); n=n^(n>>>4); n=n*0x27d4eb2d; n=n^(n>>>15); return n>>>0; }
  function rand(seed){ let s=seed>>>0; return ()=>{ s=(1664525*s+1013904223)>>>0; return (s>>>8)/16777216; }; }
  function palette(ess){
    const p={
      "Feu":["#ffb3a7","#ff6b5a","#c23b2a","#ffd36a"],
      "Eau":["#b6e3ff","#4aa3ff","#1e4ea8","#7fe8ff"],
      "Vent":["#d5fff2","#58d9c7","#1f7f7a","#bff7ff"],
      "Terre":["#f2d0a7","#c79a5a","#6b4a2b","#d8c06f"],
      "Ombre":["#d7ccff","#7a69d9","#2a2552","#a08cff"],
      "Lumière":["#fff3b6","#ffd36a","#b87d1a","#fffbe1"],
      "Foudre":["#fff0a8","#ffd11a","#7a4dd9","#b7e3ff"],
      "Nature":["#c9ffb8","#53d35a","#1f6a3a","#ffd36a"],
    };
    return p[ess]||["#e8e8f0","#9aa0b5","#2a2f52","#ffd36a"];
  }

  // Creature sprite (16x16) drawn onto a given context
  function drawCreatureSprite(cctx, ox, oy, scale, mon, flip=false){
    const seed=(mon.seed||mon.id*9973) + (mon.essences[0].charCodeAt(0)*31);
    const r=rand(hash(seed));
    const pal=palette(mon.essences[0]);
    const accent=mon.essences[1]?palette(mon.essences[1])[1]:pal[3];
    const base=pal[1], light=pal[0], dark=pal[2];

    const px=(gx,gy,col)=>{
      const x=flip ? (15-gx) : gx;
      cctx.fillStyle=col;
      cctx.fillRect(Math.round(ox+x*scale), Math.round(oy+gy*scale), scale, scale);
    };

    // shadow
    cctx.fillStyle="rgba(0,0,0,.25)";
    cctx.fillRect(Math.round(ox+4*scale), Math.round(oy+14*scale), 8*scale, 2*scale);

    const type=Math.floor(r()*4); // blob/dragon/bird/object
    const blob=()=>{
      for(let gy=4;gy<=12;gy++){
        for(let gx=4;gx<=11;gx++){
          const dx=gx-7.5, dy=gy-8.5;
          const rad=12 + r()*4;
          if(dx*dx*1.2 + dy*dy*0.9 < rad) px(gx,gy,base);
        }
      }
      for(let gy=7;gy<=11;gy++)for(let gx=6;gx<=9;gx++) px(gx,gy,light);
      px(5,3,accent); px(10,3,accent); px(5,4,accent); px(10,4,accent);
    };
    const dragon=()=>{
      for(let gy=6;gy<=12;gy++)for(let gx=5;gx<=10;gx++){
        const dx=gx-7.5, dy=gy-9.5;
        if(dx*dx*1.1+dy*dy<9+r()*3) px(gx,gy,base);
      }
      for(let gy=3;gy<=6;gy++)for(let gx=6;gx<=9;gx++) px(gx,gy,base);
      px(10,5,base); px(11,5,base); px(10,6,base);
      px(4,7,accent); px(4,8,accent); px(11,7,accent); px(11,8,accent);
      px(3,12,dark); px(4,12,dark);
    };
    const bird=()=>{
      for(let gy=6;gy<=11;gy++)for(let gx=6;gx<=9;gx++) px(gx,gy,base);
      for(let gy=3;gy<=5;gy++)for(let gx=7;gx<=8;gx++) px(gx,gy,base);
      px(9,4,accent);
      px(5,7,accent); px(10,7,accent); px(5,8,accent); px(10,8,accent);
      px(7,2,light);
    };
    const objecty=()=>{
      // simple: key/clock/stone
      const k=Math.floor(r()*3);
      if(k===0){ // clock
        for(let gy=4;gy<=12;gy++)for(let gx=5;gx<=10;gx++){
          const dx=gx-7.5, dy=gy-8;
          if(dx*dx+dy*dy<12) px(gx,gy,base);
        }
        px(7,6,light); px(8,6,light); px(7,7,light); px(8,7,light);
        px(8,8,accent); px(9,7,accent);
      } else if(k===1){ // key
        for(let gy=4;gy<=6;gy++)for(let gx=6;gx<=9;gx++) px(gx,gy,base);
        for(let gy=7;gy<=12;gy++){ px(7,gy,base); px(8,gy,base); }
        px(9,11,accent); px(10,11,accent); px(10,10,accent);
      } else { // stone
        for(let gy=6;gy<=12;gy++)for(let gx=5;gx<=10;gx++) if(r()>0.15) px(gx,gy,base);
        px(6,8,light); px(7,8,light);
      }
    };

    if(type===0) blob();
    else if(type===1) dragon();
    else if(type===2) bird();
    else objecty();

    // eyes
    px(6,6,"#111"); px(9,6,"#111");
    px(5,5,light);
  }

  // Game state
  const pool = creatures.filter(c=>c.rank!=="Primordial");
  const pick = ()=> pool[Math.floor(Math.random()*pool.length)];
  function mkFighter(c,lvl){
    const mult=1+(lvl-1)*0.06;
    return {
      id:c.id, name:c.name, seed:c.seed, essences:c.essences,
      lvl,
      hpMax:Math.floor(c.base.hp*mult),
      hp:Math.floor(c.base.hp*mult),
      atk:Math.floor(c.base.atk*mult),
      def:Math.floor(c.base.def*mult),
      spd:Math.floor(c.base.spd*mult),
      moves: JSON.parse(JSON.stringify(c.moveset)),
    };
  }

  const state={
    zoneId:1,
    mapId:"map_village",
    map:null,
    tileSize:16,
    cam:{x:0,y:0},
    player:{x:6,y:14,dir:"down",anim:0,speed:3.2},
    team:[mkFighter(pick(),6), mkFighter(pick(),5), mkFighter(pick(),4)],
    activeIdx:0,
    inventory:{potion:2, ether:0},
    opened:{},
    inBattle:false,
    battle:null
  };

  function zone(){ return zones.zones.find(z=>z.id===state.zoneId) || zones.zones[0]; }

  function updateHUD(){
    mapNameEl.textContent=state.map?.name||"—";
    const z=zone();
    zoneNameEl.textContent=z.name;
    lvlRangeEl.textContent=`${z.level_range[0]}–${z.level_range[1]}`;
    coordEl.textContent=`${state.player.x.toFixed(2)}, ${state.player.y.toFixed(2)}`;
    teamEl.textContent=state.team.map((t,i)=> i===state.activeIdx?`[${t.name} Lv${t.lvl}]`:`${t.name} Lv${t.lvl}`).join(", ");
  }

  // Save/Load
  const SAVE_KEY="mythomon_save_v3";
  function saveGame(){
    localStorage.setItem(SAVE_KEY, JSON.stringify({
      zoneId:state.zoneId, mapId:state.mapId, player:state.player,
      team:state.team, activeIdx:state.activeIdx, inventory:state.inventory, opened:state.opened
    }));
    log("Sauvegarde OK.");
  }
  async function loadGame(){
    const raw=localStorage.getItem(SAVE_KEY);
    if(!raw){ log("Aucune sauvegarde."); return; }
    const d=JSON.parse(raw);
    state.zoneId=d.zoneId??1;
    state.activeIdx=d.activeIdx??0;
    state.inventory=d.inventory??state.inventory;
    state.opened=d.opened??{};
    state.team=d.team??state.team;
    await loadMap(d.mapId??"map_village", d.player?.x, d.player?.y);
    state.player=d.player??state.player;
    updateHUD();
    log("Sauvegarde chargée.");
  }
  btnSave.onclick=saveGame;
  btnLoad.onclick=()=>loadGame();

  // Map loading
  async function loadMap(mapId, x=null, y=null){
    const m=await fetch(`/data/maps/${mapId}.json`).then(r=>r.json());
    state.mapId=mapId;
    state.map=m;
    state.tileSize=m.tileSize||16;
    state.player.x = (x!=null)?x:(m.spawn?.x??2);
    state.player.y = (y!=null)?y:(m.spawn?.y??2);
    log(`Map: ${m.name}`);
  }

  function tileAt(x,y){
    const xi=Math.floor(x), yi=Math.floor(y);
    const row=state.map.tiles[yi]||"";
    return row[xi]||"#";
  }
  function solid(ch){ return ch==="#"||ch==="T"||ch==="H"||ch==="R"||ch==="F"||ch==="X"; }
  function encounter(ch){ return ch===","; }

  function checkLink(){
    const px=Math.floor(state.player.x), py=Math.floor(state.player.y);
    for(const l of (state.map.links||[])){
      if(l.from.x===px && l.from.y===py){
        if(l.type==="zone") state.zoneId = (l.to.map==="map_coast") ? 2 : 1;
        return loadMap(l.to.map, l.to.x, l.to.y);
      }
    }
    return null;
  }

  function checkChest(){
    const px=Math.floor(state.player.x), py=Math.floor(state.player.y);
    for(const c of (state.map.chests||[])){
      const key=`${state.mapId}:${c.id}`;
      if(c.x===px && c.y===py && !state.opened[key]){
        state.opened[key]=true;
        if(c.loot?.id==="potion") state.inventory.potion=(state.inventory.potion||0)+(c.loot.qty||1);
        if(c.loot?.id==="ether") state.inventory.ether=(state.inventory.ether||0)+(c.loot.qty||1);
        log(`Coffre: +${c.loot?.name} x${c.loot?.qty||1}`);
        showModal("Coffre", `<div>Tu trouves: <b>${c.loot?.name}</b> x${c.loot?.qty||1}</div>`, [{label:"OK", onClick:closeModal}]);
        return true;
      }
    }
    return false;
  }

  function nearbyNpc(){
    for(const n of (state.map.npcs||[])){
      const dx=Math.abs(n.x-Math.floor(state.player.x));
      const dy=Math.abs(n.y-Math.floor(state.player.y));
      if(dx+dy===1) return n;
    }
    return null;
  }
  function talk(npc){
    let i=0;
    const render=()=>{
      showModal("Dialogue", `<div style="padding:6px 0"><b>PNJ</b> : ${npc.dialog[i]||""}</div>`, [
        {label:i<npc.dialog.length-1?"Suivant":"Fin", onClick:()=>{ if(i<npc.dialog.length-1){ i++; render(); } else closeModal(); }}
      ]);
    };
    render();
  }
  function interact(){
    if(state.inBattle) return;
    const npc=nearbyNpc();
    if(npc) return talk(npc);
    log("Rien à interagir.");
  }
  aBtn.onclick=interact;
  addEventListener("keydown",(e)=>{ if(e.key.toLowerCase()==="e" || e.key==="Enter") interact(); });
  canvas.addEventListener("click", interact);

  // UI: Party/Codex with sprites
  function drawMini(cv, mon){
    const cctx=cv.getContext("2d");
    cctx.imageSmoothingEnabled=false;
    cctx.clearRect(0,0,cv.width,cv.height);
    cctx.fillStyle="rgba(0,0,0,0.18)";
    cctx.fillRect(0,0,cv.width,cv.height);
    drawCreatureSprite(cctx, 8, 8, 4, mon, false);
  }
  btnParty.onclick=()=>{
    const rows=state.team.map((t,idx)=>`<div style="display:flex;gap:12px;align-items:center;padding:10px;border:1px solid rgba(255,255,255,.10);border-radius:12px;margin-bottom:8px;background:rgba(255,255,255,.02)">
      <canvas data-s="${idx}" width="64" height="64" style="image-rendering:pixelated;border-radius:10px;border:1px solid rgba(255,255,255,.10)"></canvas>
      <div style="flex:1">
        <div><b>${t.name}</b> <span style="opacity:.8">Lv${t.lvl}</span> <span style="opacity:.8">(${t.essences.join("/")})</span></div>
        <div style="opacity:.85;font-size:12px">HP ${t.hp}/${t.hpMax} • ATK ${t.atk} • DEF ${t.def}</div>
        <div style="opacity:.75;font-size:12px">PP: ${t.moves.map(m=>`${m.name} ${m.pp}/${m.ppMax}`).join(" • ")}</div>
      </div>
      <button data-a="${idx}">${idx===state.activeIdx?"Actif":"Choisir"}</button>
    </div>`).join("");
    showModal("Ton équipe", rows, [{label:"Fermer", onClick:closeModal}]);
    state.team.forEach((t,idx)=>{ const cv=modalBody.querySelector(`canvas[data-s="${idx}"]`); if(cv) drawMini(cv,t); });
    modalBody.querySelectorAll("[data-a]").forEach(b=>{ b.onclick=()=>{ state.activeIdx=Number(b.getAttribute("data-a")); log(`Actif: ${state.team[state.activeIdx].name}`); closeModal(); updateHUD(); }; });
  };

  btnCodex.onclick=()=>{
    const first=creatures.slice(0,36);
    const rows=first.map(c=>`<div style="display:flex;gap:10px;align-items:center;padding:8px;border:1px solid rgba(255,255,255,.10);border-radius:12px;margin-bottom:8px;background:rgba(255,255,255,.02)">
      <canvas data-c="${c.id}" width="48" height="48" style="image-rendering:pixelated;border-radius:10px;border:1px solid rgba(255,255,255,.10)"></canvas>
      <div style="flex:1"><b>${c.name}</b> <span style="opacity:.8">(${c.essences.join("/")})</span> <span style="opacity:.7">• ${c.rank}</span></div>
    </div>`).join("");
    showModal("Codex (aperçu)", `<div style="opacity:.75;font-size:12px;margin-bottom:8px">Aperçu des 36 premiers (démo).</div>${rows}`, [{label:"Fermer", onClick:closeModal}]);
    first.forEach(c=>{ const cv=modalBody.querySelector(`canvas[data-c="${c.id}"]`); if(cv){ const cctx=cv.getContext("2d"); cctx.imageSmoothingEnabled=false; cctx.fillStyle="rgba(0,0,0,0.18)"; cctx.fillRect(0,0,48,48); drawCreatureSprite(cctx, 3, 3, 2, c, false);} });
  };

  // Battle
  function randomEnemy(){
    const z=zone();
    const lvl=Math.floor(z.level_range[0] + Math.random()*(z.level_range[1]-z.level_range[0]+1));
    return mkFighter(pick(), lvl);
  }
  function startBattle(){
    const enemy=randomEnemy();
    state.inBattle=true;
    state.battle={enemy, buff:false};
    log(`Rencontre: ${enemy.name} (Lv${enemy.lvl})`);
    renderBattle();
  }
  function endBattle(msg){
    state.inBattle=false;
    state.battle=null;
    closeModal();
    showModal("Fin du duel", `<div>${msg}</div>`, [{label:"OK", onClick:closeModal}]);
  }
  function dmg(att,def,power){
    return Math.max(1, Math.floor(power + att.atk - Math.floor(def.def/2)));
  }

  function useEther(){
    if((state.inventory.ether||0)<=0){ log("Pas d'Éther."); return false; }
    state.inventory.ether -= 1;
    const me=state.team[state.activeIdx];
    let best=null, bestRatio=1;
    for(const m of me.moves){
      if(m.key==="m4") continue;
      const r=m.pp/m.ppMax;
      if(r<bestRatio){ bestRatio=r; best=m; }
    }
    if(best){ best.pp=Math.min(best.ppMax, best.pp+5); log(`Éther: +5 PP sur ${best.name}`); }
    return true;
  }

  function battleUI(){
    const me=state.team[state.activeIdx];
    const en=state.battle.enemy;
    const hp=(cur,max)=>{ const p=Math.max(0,Math.min(1,cur/max)); const w=Math.floor(p*160); return `<div style="width:160px;height:10px;border-radius:6px;background:rgba(255,255,255,.10);overflow:hidden;border:1px solid rgba(255,255,255,.12)"><div style="height:100%;width:${w}px;background:rgba(120,220,120,.85)"></div></div><div style="font-size:12px;opacity:.85">${cur}/${max}</div>`; };
    const moveBtn=(m)=>`<button class="mBtn" data-m="${m.key}" ${m.pp<=0?"disabled":""}>${m.name}<div class="mSub">PP ${m.pp}/${m.ppMax}</div></button>`;
    return `
      <style>
        .top{display:grid;grid-template-columns:1fr 1fr;gap:10px}
        .card{border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:10px;background:rgba(255,255,255,.03)}
        .scene{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:end;margin-top:8px}
        .pad{height:120px;border-radius:14px;background:linear-gradient(180deg, rgba(90,130,210,.18), rgba(30,40,80,.18));border:1px solid rgba(255,255,255,.10);position:relative;overflow:hidden}
        .moves{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
        .mBtn{background:#2a2f52;color:#fff;border:1px solid rgba(255,255,255,.12);padding:10px;border-radius:12px;font-weight:900;text-align:left}
        .mBtn:disabled{opacity:.45}
        .mSub{font-size:11px;opacity:.75;margin-top:3px}
        .small{font-size:12px;opacity:.75}
      </style>
      <div class="top">
        <div class="card"><div><b>${me.name}</b> <span style="opacity:.8">Lv${me.lvl}</span> <span class="small">(${me.essences.join("/")})</span></div>${hp(me.hp,me.hpMax)}</div>
        <div class="card"><div><b>${en.name}</b> <span style="opacity:.8">Lv${en.lvl}</span> <span class="small">(${en.essences.join("/")})</span></div>${hp(en.hp,en.hpMax)}</div>
      </div>
      <div class="scene">
        <div class="pad"><canvas id="meSprite" width="160" height="120" style="image-rendering:pixelated"></canvas></div>
        <div class="pad"><canvas id="enSprite" width="160" height="120" style="image-rendering:pixelated"></canvas></div>
      </div>
      <div class="moves">${me.moves.map(moveBtn).join("")}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
        <button id="btnPotion">Potion (${state.inventory.potion||0})</button>
        <button id="btnEther">Éther (${state.inventory.ether||0})</button>
        <button id="btnSwitch">Changer</button>
        <button id="btnRun">Fuir</button>
      </div>
      <div class="small">Astuce: Capture est plus simple quand l'ennemi est faible.</div>
    `;
  }

  function renderBattle(){
    showModal("Combat", battleUI(), [{label:"Fermer", onClick:()=>{}}]);
    const me=state.team[state.activeIdx];
    const en=state.battle.enemy;

    // draw sprites
    const mcv=modalBody.querySelector("#meSprite"), ecv=modalBody.querySelector("#enSprite");
    const mctx=mcv.getContext("2d"), ectx=ecv.getContext("2d");
    mctx.imageSmoothingEnabled=false; ectx.imageSmoothingEnabled=false;

    const bg=(cctx)=>{
      cctx.clearRect(0,0,160,120);
      cctx.fillStyle="rgba(0,0,0,0.15)"; cctx.fillRect(0,0,160,120);
      cctx.fillStyle="rgba(255,255,255,0.06)";
      for(let i=0;i<12;i++) cctx.fillRect((i*13)%160,(i*9)%120,2,2);
      cctx.fillStyle="rgba(0,0,0,0.10)"; cctx.fillRect(0,100,160,20);
    };
    bg(mctx); bg(ectx);
    drawCreatureSprite(mctx, 32, 20, 6, me, false);
    drawCreatureSprite(ectx, 32, 20, 6, en, true);

    // wire buttons
    modalBody.querySelectorAll("[data-m]").forEach(b=> b.onclick=()=>playerMove(b.getAttribute("data-m")));
    modalBody.querySelector("#btnPotion").onclick=()=>{
      if((state.inventory.potion||0)<=0){ log("Plus de potion."); return; }
      state.inventory.potion -= 1;
      me.hp=Math.min(me.hpMax, me.hp+35);
      log("Potion: +35 PV");
      enemyTurn();
    };
    modalBody.querySelector("#btnEther").onclick=()=>{
      if(useEther()) enemyTurn();
    };
    modalBody.querySelector("#btnSwitch").onclick=()=>{
      const opts=state.team.map((t,i)=>({t,i})).filter(o=>o.t.hp>0);
      const body=opts.map(o=>`<div style="display:flex;gap:10px;align-items:center;margin-bottom:8px"><div style="flex:1"><b>${o.t.name}</b> Lv${o.t.lvl} — HP ${o.t.hp}/${o.t.hpMax}</div><button data-sw="${o.i}">Choisir</button></div>`).join("");
      showModal("Changer", body, [{label:"Retour", onClick:renderBattle}]);
      modalBody.querySelectorAll("[data-sw]").forEach(b=> b.onclick=()=>{ state.activeIdx=Number(b.getAttribute("data-sw")); log(`Changement: ${state.team[state.activeIdx].name}`); enemyTurn(); });
    };
    modalBody.querySelector("#btnRun").onclick=()=>endBattle("Tu as fui.");
  }

  function playerMove(key){
    const me=state.team[state.activeIdx];
    const en=state.battle.enemy;
    const m=me.moves.find(x=>x.key===key);
    if(!m || m.pp<=0){ log("Action impossible (PP)."); return; }
    m.pp -= 1;

    if(key==="m3"){ state.battle.buff=true; log("Focus: puissance augmentée."); enemyTurn(); return; }
    if(key==="m4"){
      const hpPct=en.hp/en.hpMax;
      const chance=Math.max(0.10, 0.60 - hpPct*0.50);
      if(Math.random()<chance){ log(`Capture réussie: ${en.name} !`); endBattle("Capture réussie !"); }
      else { log("Capture échouée."); enemyTurn(); }
      return;
    }

    let power=m.power;
    if(state.battle.buff) power=Math.floor(power*1.25);
    const d=dmg(me,en,power);
    en.hp=Math.max(0,en.hp-d);
    log(`${m.name}: -${d} PV`);
    if(en.hp<=0){
      me.lvl=Math.min(99, me.lvl+1);
      me.hpMax=Math.floor(me.hpMax*1.05);
      me.atk=Math.floor(me.atk*1.03);
      me.def=Math.floor(me.def*1.03);
      me.hp=Math.min(me.hpMax, me.hp+18);
      updateHUD();
      endBattle(`Victoire ! ${me.name} passe Lv${me.lvl}.`);
      return;
    }
    enemyTurn();
  }

  function enemyTurn(){
    const me=state.team[state.activeIdx];
    const en=state.battle.enemy;
    const d=dmg(en,me,16);
    me.hp=Math.max(0,me.hp-d);
    log(`Ennemi attaque: -${d} PV`);
    if(me.hp<=0){
      log(`${me.name} est K.O.`);
      const idx=state.team.findIndex(t=>t.hp>0);
      if(idx>=0){ state.activeIdx=idx; log(`Tu envoies ${state.team[idx].name}.`); }
      else { endBattle("Défaite…"); return; }
    }
    renderBattle();
  }

  // Tile drawing (more lively)
  function pxRect(x,y,w,h){ ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h)); }
  function drawGrass(px,py,seed){
    ctx.fillStyle="#1f6a3a"; pxRect(px,py,16,16);
    ctx.fillStyle="rgba(255,255,255,0.06)";
    for(let i=0;i<3;i++){ const dx=(seed*13+i*5)%14, dy=(seed*7+i*9)%14; pxRect(px+dx,py+dy,2,2); }
  }
  function drawTall(px,py,seed,t){
    ctx.fillStyle="#246f3f"; pxRect(px,py,16,16);
    for(let i=0;i<5;i++){ const dx=(seed*11+i*3)%16; const sway=Math.sin(t*3+seed+i)*1.2; ctx.fillStyle="rgba(255,255,255,0.10)"; pxRect(px+dx,py+3+sway,1,10); }
  }
  function drawWater(px,py,t){
    ctx.fillStyle="#1f4b8a"; pxRect(px,py,16,16);
    ctx.fillStyle="rgba(255,255,255,0.14)";
    const yy=py+4+Math.floor((Math.sin(t*2+(px+py)*0.02)+1)*2);
    pxRect(px+2,yy,12,2);
    ctx.fillStyle="rgba(0,0,0,0.10)"; pxRect(px,py+13,16,3);
  }
  function drawCliff(px,py){
    ctx.fillStyle="#4b445a"; pxRect(px,py,16,16);
    ctx.fillStyle="rgba(0,0,0,0.20)"; pxRect(px,py,16,3);
    ctx.fillStyle="rgba(255,255,255,0.06)"; pxRect(px+2,py+5,12,2);
  }
  function drawPath(px,py){
    ctx.fillStyle="#8a6a46"; pxRect(px,py,16,16);
    ctx.fillStyle="rgba(255,255,255,0.06)"; pxRect(px+2,py+2,12,2);
    ctx.fillStyle="rgba(0,0,0,0.10)"; pxRect(px,py+13,16,3);
  }
  function drawTree(px,py,t,seed){
    ctx.fillStyle="#6a4b2f"; pxRect(px+7,py+9,2,6);
    ctx.fillStyle="#1f5f35"; pxRect(px+3,py+3,10,8);
    const bob=Math.sin(t*2+seed*0.01)*1.2;
    ctx.fillStyle="rgba(255,255,255,0.06)"; pxRect(px+4,py+4+bob,3,2);
  }
  function drawHouse(px,py){
    ctx.fillStyle="#6a4b2f"; pxRect(px,py,16,16);
    ctx.fillStyle="#3a2a1d"; pxRect(px+3,py+5,10,8);
    ctx.fillStyle="rgba(255,255,255,0.10)"; pxRect(px+4,py+6,8,2);
  }
  function drawDoor(px,py){
    ctx.fillStyle="#6a4b2f"; pxRect(px,py,16,16);
    ctx.fillStyle="#1d1a10"; pxRect(px+5,py+5,6,10);
    ctx.fillStyle="#d9c27a"; pxRect(px+10,py+10,2,2);
  }
  function drawFence(px,py){
    ctx.fillStyle="#6a4b2f"; pxRect(px,py+6,16,6);
    ctx.fillStyle="rgba(0,0,0,0.12)"; pxRect(px,py+11,16,2);
    ctx.fillStyle="#6a4b2f"; pxRect(px+3,py+3,2,12); pxRect(px+11,py+3,2,12);
    ctx.fillStyle="rgba(255,255,255,0.06)"; pxRect(px+4,py+7,8,1);
  }
  function drawBush(px,py,seed,t){
    ctx.fillStyle="#2f8f4e"; pxRect(px,py,16,16);
    ctx.fillStyle="#53d35a"; pxRect(px+3,py+6,10,7);
    const sparkle=((seed+Math.floor(t*6))%11)===0;
    if(sparkle){ ctx.fillStyle="rgba(255,255,255,.45)"; pxRect(px+10,py+5,2,2); }
  }
  function drawSand(px,py,seed){
    ctx.fillStyle="#b89b4b"; pxRect(px,py,16,16);
    ctx.fillStyle="rgba(0,0,0,0.06)"; const dx=(seed*9)%12; pxRect(px+dx,py+9,4,2);
    ctx.fillStyle="rgba(255,255,255,0.05)"; pxRect(px+2,py+3,2,2);
  }
  function drawRock(px,py){
    ctx.fillStyle="#3b3a3a"; pxRect(px,py,16,16);
    ctx.fillStyle="rgba(255,255,255,0.06)"; pxRect(px+2,py+2,12,2);
    ctx.fillStyle="rgba(0,0,0,0.12)"; pxRect(px+2,py+12,12,2);
  }
  function drawGate(px,py,t){
    ctx.fillStyle="#7c2a62"; pxRect(px,py,16,16);
    ctx.fillStyle="rgba(255,255,255,0.12)"; pxRect(px+4,py+4,8,2); pxRect(px+4,py+9,8,2);
    const glow=(Math.sin(t*4)+1)*0.5;
    ctx.fillStyle=`rgba(255,255,255,${0.08+glow*0.08})`; pxRect(px+6,py+6,4,4);
  }
  function drawNpc(px,py){
    ctx.fillStyle="#39b2b2"; pxRect(px+5,py+6,6,8);
    ctx.fillStyle="#f7d7c4"; pxRect(px+5,py+2,6,5);
    ctx.fillStyle="rgba(0,0,0,0.25)"; pxRect(px+6,py+4,4,1);
  }
  function drawChest(px,py){
    ctx.fillStyle="#a67a2c"; pxRect(px+3,py+7,10,7);
    ctx.fillStyle="#5a3a12"; pxRect(px+3,py+11,10,3);
    ctx.fillStyle="#d9c27a"; pxRect(px+7,py+10,2,2);
  }
  function drawPlayer(px,py,t,vx,vy){
    ctx.fillStyle="rgba(0,0,0,0.25)"; pxRect(px+5,py+13,6,2);
    const walking=(Math.abs(vx)+Math.abs(vy))>0.01;
    const bob=walking?Math.sin(t*10+state.player.anim)*1.2:0;
    ctx.fillStyle="#f2e9ff"; pxRect(px+6,py+7+bob,4,6);
    ctx.fillStyle="#f7d7c4"; pxRect(px+5,py+3+bob,6,5);
    ctx.fillStyle="#5c4b9a"; pxRect(px+5,py+3+bob,6,2); pxRect(px+6,py+5+bob,4,1);
    ctx.fillStyle="#1a1a1a";
    if(state.player.dir==="down"){ pxRect(px+6,py+6+bob,1,1); pxRect(px+9,py+6+bob,1,1); }
    else if(state.player.dir==="left"){ pxRect(px+6,py+6+bob,1,1); }
    else if(state.player.dir==="right"){ pxRect(px+9,py+6+bob,1,1); }
    else { pxRect(px+6,py+6+bob,1,1); pxRect(px+9,py+6+bob,1,1); }
    ctx.fillStyle="#d45a6a"; pxRect(px+6,py+8+bob,4,1);
    ctx.fillStyle="#3a3343";
    if(walking){ const step=Math.sin(t*10); pxRect(px+6,py+13+bob,2,1); pxRect(px+8,py+13+bob+(step>0?0:1),2,1); }
    else pxRect(px+6,py+13+bob,4,1);
  }

  // Main loop
  let last=performance.now(), time=0, vx=0, vy=0;
  function render(t){
    const ts=state.tileSize;
    ctx.clearRect(0,0,canvas.width,canvas.height);

    for(let y=0;y<state.map.height;y++){
      const row=state.map.tiles[y];
      for(let x=0;x<state.map.width;x++){
        const ch=row[x];
        const px=x*ts-state.cam.x, py=y*ts-state.cam.y;
        if(px+ts<0||py+ts<0||px>canvas.width||py>canvas.height) continue;
        const seed=(x+1)*97+(y+1)*131;
        if(ch===".") drawGrass(px,py,seed);
        else if(ch===",") drawTall(px,py,seed,t);
        else if(ch==="~") drawWater(px,py,t);
        else if(ch==="#") drawCliff(px,py);
        else if(ch==="P") drawPath(px,py);
        else if(ch==="T") drawTree(px,py,t,seed);
        else if(ch==="H") drawHouse(px,py);
        else if(ch==="D") drawDoor(px,py);
        else if(ch==="F") drawFence(px,py);
        else if(ch==="B") drawBush(px,py,seed,t);
        else if(ch==="S") drawSand(px,py,seed);
        else if(ch==="R") drawRock(px,py);
        else if(ch==="G") drawGate(px,py,t);
        else drawGrass(px,py,seed);
      }
    }

    // chests
    for(const c of (state.map.chests||[])){
      const key=`${state.mapId}:${c.id}`;
      if(state.opened[key]) continue;
      drawChest(c.x*ts-state.cam.x, c.y*ts-state.cam.y);
    }

    // NPCs + bubble
    for(const n of (state.map.npcs||[])){
      const px=n.x*ts-state.cam.x, py=n.y*ts-state.cam.y;
      drawNpc(px,py);
      const dx=Math.abs(n.x-Math.floor(state.player.x));
      const dy=Math.abs(n.y-Math.floor(state.player.y));
      if(dx+dy===1){
        ctx.fillStyle="rgba(255,255,255,0.85)";
        ctx.fillRect(Math.round(px+6),Math.round(py-4),4,4);
      }
    }

    // player
    drawPlayer(state.player.x*ts-state.cam.x, state.player.y*ts-state.cam.y, t, vx, vy);

    // vignette
    const g=ctx.createRadialGradient(canvas.width/2,canvas.height/2,60,canvas.width/2,canvas.height/2,420);
    g.addColorStop(0,"rgba(0,0,0,0)");
    g.addColorStop(1,"rgba(0,0,0,0.22)");
    ctx.fillStyle=g; ctx.fillRect(0,0,canvas.width,canvas.height);
  }

  function step(now){
    const dt=Math.min(0.033,(now-last)/1000);
    last=now; time+=dt;
    if(!state.map){ requestAnimationFrame(step); return; }
    if(state.inBattle){ requestAnimationFrame(step); return; }

    let ix=0, iy=0;
    if(keys["arrowleft"]||keys["a"]) ix-=1;
    if(keys["arrowright"]||keys["d"]) ix+=1;
    if(keys["arrowup"]||keys["w"]) iy-=1;
    if(keys["arrowdown"]||keys["s"]) iy+=1;

    ix+=joyVec.x; iy+=joyVec.y;
    const len=Math.hypot(ix,iy); if(len>1){ ix/=len; iy/=len; }
    vx=ix*state.player.speed; vy=iy*state.player.speed;

    if(Math.abs(ix)>Math.abs(iy)){ if(ix<-0.1) state.player.dir="left"; if(ix>0.1) state.player.dir="right"; }
    else { if(iy<-0.1) state.player.dir="up"; if(iy>0.1) state.player.dir="down"; }
    if(Math.hypot(ix,iy)>0.05) state.player.anim += dt;

    const nx=state.player.x + ix*state.player.speed*dt;
    const ny=state.player.y + iy*state.player.speed*dt;
    const tx=tileAt(nx, state.player.y); if(!solid(tx)) state.player.x=nx;
    const ty=tileAt(state.player.x, ny); if(!solid(ty)) state.player.y=ny;

    const ts=state.tileSize;
    const targetX=state.player.x*ts - canvas.width/2 + ts/2;
    const targetY=state.player.y*ts - canvas.height/2 + ts/2;
    state.cam.x += (targetX-state.cam.x)*0.12;
    state.cam.y += (targetY-state.cam.y)*0.12;

    checkChest();
    const lp=checkLink(); if(lp) lp.then(()=>updateHUD());

    const ch=tileAt(state.player.x, state.player.y);
    if(encounter(ch) && Math.random()<0.010) startBattle();

    updateHUD();
    render(time);
    requestAnimationFrame(step);
  }

  // start
  await loadMap(state.mapId);
  updateHUD();
  log("Démo v3: explore, maisons, rivage. E/Entrée/A pour parler. Hautes herbes = combats.");
  requestAnimationFrame(step);
})();
