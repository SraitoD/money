# MythoMon — Démo GBA v3 (plus jolie)

## Features
- 2 maps détaillées : Village d'Éveil + Rivage Azuré
- Entrer/sortir de 3 maisons + phare
- PNJ avec dialogues (E / Entrée / bouton A mobile)
- Coffres (Potion + Éther)
- Rencontres aléatoires (hautes herbes)
- Combat jouable avec sprites procéduraux + PP
- Potion + Éther (récup PP)
- Save/Load
- Serveur écoute sur 0.0.0.0 (accessible depuis téléphone via IP)

## Lancer
```bash
cd server
npm install
npm start
```

- PC: http://localhost:3000
- Téléphone: http://IP_DU_RASPBERRY:3000 (IP via `hostname -I`)
