# Tower Lab (Expo / React Native)

A simple physics-based tower-building prototype using **Expo + react-native-game-engine + matter-js**.

## Features (MVP)
- Start each run with **100 points**
- Drag & drop blocks to build a tower
- Tap **TEST** to drop weights on the tower
- Stability meter + score changes
- Kid-friendly, modern UI (no retro/neon)

## Setup
```bash
npm install
npx expo start
```

### If you're not on the same Wi‑Fi:
```bash
npx expo start --tunnel
```

## Controls
- Drag blocks from the bottom palette into the scene
- Press **TEST** to spawn weights and stress the tower
- Press **RESET** to restart

## Notes
This is a prototype starter. Next steps:
- Better snapping & rotation
- Level generator (difficulty curve 1..100)
- AI opponent (heuristics + simulation)
