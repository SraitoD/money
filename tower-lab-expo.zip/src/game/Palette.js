import React from "react";
import { View, Text } from "react-native";
import { Colors } from "./colors";

export function Palette() {
  return (
    <View
      style={{
        position: "absolute",
        left: 14,
        right: 14,
        bottom: 18,
        backgroundColor: Colors.panel,
        borderRadius: 18,
        padding: 12,
        borderWidth: 1,
        borderColor: "rgba(0,0,0,0.04)",
        shadowColor: "#000",
        shadowOpacity: 0.06,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 6 },
        elevation: 2,
      }}
    >
      <Text style={{ color: Colors.text, fontWeight: "900" }}>Palette</Text>
      <Text style={{ color: Colors.subtext, fontWeight: "600", marginTop: 4 }}>
        Appuie + glisse dans la zone de jeu pour poser un bloc.
      </Text>
      <View style={{ marginTop: 10, flexDirection: "row", gap: 10 }}>
        <View style={{ width: 70, height: 26, borderRadius: 12, backgroundColor: "#FFE08A", borderWidth: 2, borderColor: "rgba(0,0,0,0.06)" }} />
        <View style={{ width: 52, height: 26, borderRadius: 12, backgroundColor: "#B8F1D0", borderWidth: 2, borderColor: "rgba(0,0,0,0.06)" }} />
        <View style={{ width: 36, height: 26, borderRadius: 12, backgroundColor: "#FFD1E8", borderWidth: 2, borderColor: "rgba(0,0,0,0.06)" }} />
      </View>
    </View>
  );
}
