import { GAME, WORLD } from "../constants";

export const stabilitySystem = (entities, { dispatch }) => {
  const blocks = Object.values(entities).filter((e) => e?.type === "block" && e?.body);

  if (blocks.length === 0) {
    entities.hud.stability = 1;
    entities.hud.maxAngleDeg = 0;
    return entities;
  }

  let maxAngle = 0;
  let avgSpeed = 0;

  for (const b of blocks) {
    const angleDeg = Math.abs((b.body.angle * 180) / Math.PI);
    maxAngle = Math.max(maxAngle, angleDeg);

    const v = b.body.velocity;
    const speed = Math.sqrt(v.x * v.x + v.y * v.y);
    avgSpeed += speed;
  }

  avgSpeed /= blocks.length;

  const angleFactor = Math.max(0, 1 - maxAngle / GAME.stabilityAngleDeg);
  const speedFactor = Math.max(0, 1 - avgSpeed / 6.5);
  const stability = Math.max(0, Math.min(1, 0.65 * angleFactor + 0.35 * speedFactor));

  entities.hud.stability = stability;
  entities.hud.maxAngleDeg = maxAngle;

  const anyBelowFloor = blocks.some((b) => b.body.position.y > WORLD.height + 60);
  const fail = maxAngle > GAME.stabilityAngleDeg + 8 || anyBelowFloor;

  if (fail && !entities.hud.failed) {
    entities.hud.failed = true;
    dispatch({ type: "FAILED" });
  }

  return entities;
};
