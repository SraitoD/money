import Matter from "matter-js";
import { WORLD } from "../constants";

export const cleanupSystem = (entities) => {
  const world = entities.physics.world;

  for (const [key, e] of Object.entries(entities)) {
    if (!e?.body) continue;
    const y = e.body.position.y;
    const x = e.body.position.x;

    if (y > WORLD.height + 200 || x < -200 || x > WORLD.width + 200) {
      Matter.World.remove(world, e.body);
      delete entities[key];
    }
  }
  return entities;
};
