import { addWeight } from "../physics";
import { PIECE, WORLD } from "../constants";

export const testSystem = (entities, { time }) => {
  const hud = entities.hud;
  if (!hud.testing || hud.failed) return entities;

  hud.testTimer += time.delta;

  // Drop a weight every ~900ms
  if (hud.testTimer > 900 && hud.weightsDropped < hud.targetWeights) {
    hud.testTimer = 0;

    const x = WORLD.width * (0.25 + Math.random() * 0.5);
    const y = 40;

    const id = `weight_${Date.now()}_${hud.weightsDropped}`;
    const body = addWeight(entities.physics.world, x, y, PIECE.weightR);

    entities[id] = {
      body,
      type: "weight",
      color: "#5A7DFF",
      renderer: require("../entities/Circle").default,
    };

    hud.weightsDropped += 1;
  }

  // Finish test and reward
  if (hud.weightsDropped >= hud.targetWeights) {
    hud.finishTimer += time.delta;
    if (hud.finishTimer > 1400) {
      hud.testing = false;
      hud.finishTimer = 0;
      hud.testTimer = 0;

      // Reward for surviving the test
      const reward = Math.round(15 + hud.stability * 35);
      hud.score = Math.min(9999, hud.score + reward);
      hud.rounds += 1;
    }
  }

  return entities;
};
