import { PIECE, WORLD } from "../constants";
import { addBlock } from "../physics";

export const dragDropSystem = (entities, { touches, dispatch }) => {
  const hud = entities.hud;

  const start = touches.find((t) => t.type === "start");
  const move = touches.find((t) => t.type === "move");
  const end = touches.find((t) => t.type === "end");

  if (start) {
    const { pageX: x, pageY: y } = start.event;
    const inPalette = y > WORLD.height - 120;

    if (inPalette && hud.blocksPlaced < hud.maxBlocks && !hud.testing && !hud.failed) {
      hud.dragging = true;
      hud.ghost = { x, y, w: PIECE.blockW, h: PIECE.blockH };
    }
  }

  if (move && hud.dragging && hud.ghost) {
    const { pageX: x, pageY: y } = move.event;
    hud.ghost.x = x;
    hud.ghost.y = y;
  }

  if (end && hud.dragging && hud.ghost) {
    const { x, y, w, h } = hud.ghost;

    if (y < WORLD.height - 140) {
      const id = `block_${Date.now()}`;
      const body = addBlock(entities.physics.world, x, y, w, h);

      entities[id] = {
        body,
        type: "block",
        color: "#FFE08A",
        renderer: require("../entities/Box").default,
      };
      hud.blocksPlaced += 1;
      hud.score = Math.max(0, hud.score - 1);
      dispatch({ type: "BLOCK_PLACED" });
    }

    hud.dragging = false;
    hud.ghost = null;
  }

  return entities;
};
