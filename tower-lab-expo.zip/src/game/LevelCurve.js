export function paramsFromDifficulty(d) {
  const D = Math.max(1, Math.min(100, d));
  const t = (D - 1) / 99;

  const targetWeights = Math.round(2 + t * 10);  // 2..12
  const timeLimitSec = Math.round(40 - t * 18);  // 40..22 (reserved for later)
  const maxBlocks = Math.round(18 - t * 8);      // 18..10

  return { targetWeights, timeLimitSec, maxBlocks };
}
