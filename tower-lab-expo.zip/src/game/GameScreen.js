import React, { useRef, useState, useMemo } from "react";
import { View } from "react-native";
import { GameEngine } from "react-native-game-engine";
import { Colors } from "./colors";
import { WORLD } from "./constants";
import Box from "./entities/Box";
import { createWorld } from "./physics";
import { physicsSystem } from "./systems/physicsSystem";
import { cleanupSystem } from "./systems/cleanupSystem";
import { dragDropSystem } from "./systems/dragDropSystem";
import { testSystem } from "./systems/testSystem";
import { stabilitySystem } from "./systems/stabilitySystem";
import { HUD } from "./HUD";
import { Palette } from "./Palette";
import { paramsFromDifficulty } from "./LevelCurve";

function buildEntities(difficulty) {
  const { engine, world, ground } = createWorld();
  const { targetWeights, maxBlocks } = paramsFromDifficulty(difficulty);

  return {
    physics: { engine, world },
    floor: { body: ground, type: "floor", color: "#E9ECF7", renderer: Box },
    hud: {
      score: 100,
      stability: 1,
      maxAngleDeg: 0,
      difficulty,
      dragging: false,
      ghost: null,
      blocksPlaced: 0,
      testing: false,
      testTimer: 0,
      finishTimer: 0,
      targetWeights,
      weightsDropped: 0,
      rounds: 0,
      failed: false,
      maxBlocks,
    },
  };
}

export default function GameScreen() {
  const engineRef = useRef(null);
  const [difficulty, setDifficulty] = useState(1);
  const [entities, setEntities] = useState(() => buildEntities(1));

  const systems = useMemo(() => [physicsSystem, cleanupSystem, dragDropSystem, testSystem, stabilitySystem], []);

  const onEvent = (e) => {
    if (e.type === "FAILED") {
      setEntities((prev) => {
        const hud = prev.hud;
        hud.score = Math.max(0, hud.score - 25);
        hud.testing = false;
        return { ...prev };
      });
    }
  };

  const startTest = () => {
    setEntities((prev) => {
      const hud = prev.hud;
      if (hud.failed || hud.testing) return prev;
      hud.testing = true;
      hud.weightsDropped = 0;
      hud.testTimer = 0;
      hud.finishTimer = 0;
      return { ...prev };
    });
  };

  const reset = () => {
    setEntities((prev) => {
      const hud = prev.hud;
      const passed = !hud.failed && !hud.testing && hud.rounds > 0 && hud.stability > 0.35;

      let nextDifficulty = difficulty;
      if (passed) nextDifficulty = Math.min(100, difficulty + 1);

      setDifficulty(nextDifficulty);
      return buildEntities(nextDifficulty);
    });
  };

  const ghost = entities?.hud?.ghost;
  const hud = entities.hud;
  const weightsInfo = `${hud.weightsDropped}/${hud.targetWeights}`;

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg }}>
      <GameEngine
        ref={engineRef}
        systems={systems}
        entities={entities}
        onEvent={onEvent}
        style={{ width: WORLD.width, height: WORLD.height, alignSelf: "center" }}
      />

      <HUD
        score={hud.score}
        stability={hud.stability}
        difficulty={hud.difficulty}
        weightsInfo={weightsInfo}
        onTest={startTest}
        onReset={reset}
        testing={hud.testing}
        failed={hud.failed}
        maxBlocks={hud.maxBlocks}
        blocksPlaced={hud.blocksPlaced}
      />

      <Palette />

      {ghost ? (
        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            left: ghost.x - ghost.w / 2,
            top: ghost.y - ghost.h / 2,
            width: ghost.w,
            height: ghost.h,
            borderRadius: 10,
            borderWidth: 2,
            borderColor: "rgba(90,125,255,0.45)",
            backgroundColor: "rgba(90,125,255,0.12)",
          }}
        />
      ) : null}
    </View>
  );
}
