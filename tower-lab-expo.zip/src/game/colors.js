export const Colors = {
  bg: "#F6F7FB",
  panel: "#FFFFFF",
  text: "#1D2433",
  subtext: "#5B647A",
  accent: "#5A7DFF",
  danger: "#FF5A5F",
  ok: "#2DD4BF",
  shadow: "rgba(0,0,0,0.08)",
};
