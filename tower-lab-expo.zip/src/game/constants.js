export const WORLD = {
  width: 360,
  height: 640,
};

export const PIECE = {
  blockW: 56,
  blockH: 22,
  weightR: 18,
};

export const GAME = {
  startScore: 100,
  maxBlocks: 20,
  stabilityAngleDeg: 22,
};
