import React from "react";
import { View, Text, Pressable } from "react-native";
import { Colors } from "./colors";

export function HUD({ score, stability, difficulty, weightsInfo, onTest, onReset, testing, failed, maxBlocks, blocksPlaced }) {
  const stabilityPct = Math.round(stability * 100);

  return (
    <View style={{ position: "absolute", top: 18, left: 14, right: 14 }}>
      <View
        style={{
          backgroundColor: Colors.panel,
          borderRadius: 16,
          padding: 12,
          shadowColor: "#000",
          shadowOpacity: 0.06,
          shadowRadius: 12,
          shadowOffset: { width: 0, height: 6 },
          elevation: 2,
          borderWidth: 1,
          borderColor: "rgba(0,0,0,0.04)",
        }}
      >
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
          <View>
            <Text style={{ fontSize: 18, fontWeight: "800", color: Colors.text }}>Score: {score}</Text>
            <Text style={{ fontSize: 13, fontWeight: "600", color: Colors.subtext }}>
              Difficulté: {difficulty} • Blocs: {blocksPlaced}/{maxBlocks}
            </Text>
          </View>

          <View style={{ alignItems: "flex-end" }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: Colors.subtext }}>
              Stabilité: {stabilityPct}%
            </Text>
            <Text style={{ fontSize: 12, fontWeight: "600", color: Colors.subtext }}>
              Poids: {weightsInfo}
            </Text>
          </View>
        </View>

        <View style={{ height: 10, backgroundColor: "rgba(90,125,255,0.15)", borderRadius: 99, marginTop: 10, overflow: "hidden" }}>
          <View style={{ height: "100%", width: `${stabilityPct}%`, backgroundColor: stabilityPct < 35 ? Colors.danger : Colors.ok }} />
        </View>

        <View style={{ flexDirection: "row", gap: 10, marginTop: 12 }}>
          <Pressable
            onPress={onTest}
            disabled={testing || failed}
            style={({ pressed }) => ({
              flex: 1,
              backgroundColor: testing || failed ? "rgba(90,125,255,0.35)" : Colors.accent,
              paddingVertical: 12,
              borderRadius: 14,
              alignItems: "center",
              opacity: pressed ? 0.9 : 1,
            })}
          >
            <Text style={{ color: "white", fontWeight: "900" }}>{testing ? "TEST..." : "TEST"}</Text>
          </Pressable>

          <Pressable
            onPress={onReset}
            style={({ pressed }) => ({
              flex: 1,
              backgroundColor: "rgba(29,36,51,0.08)",
              paddingVertical: 12,
              borderRadius: 14,
              alignItems: "center",
              opacity: pressed ? 0.9 : 1,
            })}
          >
            <Text style={{ color: Colors.text, fontWeight: "900" }}>RESET</Text>
          </Pressable>
        </View>

        {failed ? (
          <View style={{ marginTop: 10, padding: 10, backgroundColor: "rgba(255,90,95,0.10)", borderRadius: 12 }}>
            <Text style={{ color: Colors.text, fontWeight: "900" }}>Oups… la tour a craqué 😅</Text>
            <Text style={{ color: Colors.subtext, fontWeight: "600", marginTop: 3 }}>
              Astuce: base plus large + renforts en triangle !
            </Text>
          </View>
        ) : null}
      </View>
    </View>
  );
}
