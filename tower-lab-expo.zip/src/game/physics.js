import Matter from "matter-js";
import { WORLD, PIECE } from "./constants";

export function createWorld() {
  const engine = Matter.Engine.create({ enableSleeping: true });
  engine.gravity.y = 1.1;

  const world = engine.world;

  const ground = Matter.Bodies.rectangle(
    WORLD.width / 2,
    WORLD.height - 30,
    WORLD.width,
    60,
    { isStatic: true, friction: 0.9, restitution: 0.0 }
  );

  const leftWall = Matter.Bodies.rectangle(-10, WORLD.height / 2, 20, WORLD.height, { isStatic: true });
  const rightWall = Matter.Bodies.rectangle(WORLD.width + 10, WORLD.height / 2, 20, WORLD.height, { isStatic: true });

  Matter.World.add(world, [ground, leftWall, rightWall]);

  return { engine, world, ground, leftWall, rightWall };
}

export function addBlock(world, x, y, w, h, opts = {}) {
  const body = Matter.Bodies.rectangle(x, y, w, h, {
    friction: 0.8,
    restitution: 0.05,
    density: 0.0022,
    ...opts,
  });
  Matter.World.add(world, body);
  return body;
}

export function addWeight(world, x, y, r = PIECE.weightR, opts = {}) {
  const body = Matter.Bodies.circle(x, y, r, {
    friction: 0.6,
    restitution: 0.1,
    density: 0.0065,
    ...opts,
  });
  Matter.World.add(world, body);
  return body;
}
