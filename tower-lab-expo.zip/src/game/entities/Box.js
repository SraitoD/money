import React from "react";
import { View } from "react-native";
import { Colors } from "../colors";

export default function Box({ body, color }) {
  const w = body.bounds.max.x - body.bounds.min.x;
  const h = body.bounds.max.y - body.bounds.min.y;
  const x = body.position.x - w / 2;
  const y = body.position.y - h / 2;

  return (
    <View
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: w,
        height: h,
        borderRadius: 10,
        backgroundColor: color || Colors.panel,
        borderWidth: 2,
        borderColor: "rgba(0,0,0,0.06)",
        shadowColor: "#000",
        shadowOpacity: 0.08,
        shadowRadius: 8,
        shadowOffset: { width: 0, height: 4 },
        elevation: 2,
      }}
    />
  );
}
