import React from "react";
import { View } from "react-native";
import { Colors } from "../colors";

export default function Circle({ body, color }) {
  const r = body.circleRadius;
  const x = body.position.x - r;
  const y = body.position.y - r;

  return (
    <View
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: r * 2,
        height: r * 2,
        borderRadius: r,
        backgroundColor: color || Colors.accent,
        borderWidth: 2,
        borderColor: "rgba(0,0,0,0.06)",
        shadowColor: "#000",
        shadowOpacity: 0.08,
        shadowRadius: 10,
        shadowOffset: { width: 0, height: 6 },
        elevation: 3,
      }}
    />
  );
}
